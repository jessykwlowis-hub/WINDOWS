package com.lumen.lastlight

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/**
 * Todo o áudio é sintetizado em código na primeira abertura:
 * nenhum arquivo de som é necessário no APK.
 */
class Audio(private val save: Save) {
    companion object {
        const val SR = 22050
        const val SHOOT = 0; const val HIT = 1; const val KILL = 2; const val GEM = 3
        const val LEVEL = 4; const val DASH = 5; const val NOVA = 6; const val HURT = 7
        const val BOSS = 8; const val CLICK = 9; const val WIN = 10; const val LOSE = 11
        const val HEAL = 12; const val COUNT = 13
        private val TWO_PI = (2.0 * PI).toFloat()
    }

    private val rnd = Random(7)
    private val sfx = arrayOfNulls<Array<AudioTrack>>(COUNT)
    private val idx = IntArray(COUNT)
    private val music = arrayOfNulls<AudioTrack>(3)
    @Volatile private var ready = false
    @Volatile private var wanted = -1
    @Volatile private var paused = false
    private var playing = -1

    fun init() {
        Thread {
            try { build() } catch (e: Throwable) { /* áudio é opcional */ }
            ready = true
            syncMusic()
        }.also { it.isDaemon = true }.start()
    }

    fun music(kind: Int) { wanted = kind; syncMusic() }
    fun refresh() { syncMusic() }
    fun pauseAll() { paused = true; syncMusic() }
    fun resumeAll() { paused = false; syncMusic() }

    fun release() {
        try {
            for (t in music) t?.release()
            for (a in sfx) a?.forEach { it.release() }
        } catch (e: Exception) { }
    }

    @Synchronized
    private fun syncMusic() {
        if (!ready) return
        val target = if (save.musicOn && !paused) wanted else -1
        if (target == playing) return
        try {
            if (playing >= 0) music[playing]?.pause()
            if (target >= 0) music[target]?.play()
        } catch (e: Exception) { }
        playing = target
    }

    fun play(id: Int, vol: Float = 1f) {
        if (!ready || !save.sfxOn) return
        val arr = sfx[id] ?: return
        val t = arr[idx[id] % arr.size]
        idx[id]++
        try {
            t.stop()
            t.reloadStaticData()
            t.setVolume(vol)
            t.play()
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ síntese

    private fun noise() = rnd.nextFloat() * 2f - 1f

    private fun sw(f0: Float, f1: Float, dur: Float, t: Float): Float =
        sin(TWO_PI * (f0 * t + (f1 - f0) * t * t / (2f * dur)))

    private fun gen(dur: Float, vol: Float, fn: (Float, Float) -> Float): ShortArray {
        val n = (dur * SR).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i / SR.toFloat()
            val p = i / n.toFloat()
            val att = min(1f, i / (0.004f * SR))
            val env = att * (1f - p) * (1f - p)
            val v = fn(t, p) * env * vol
            out[i] = (v.coerceIn(-1f, 1f) * 32000f).toInt().toShort()
        }
        return out
    }

    private fun arp(notes: FloatArray, dur: Float, vol: Float): ShortArray = gen(dur, vol) { t, p ->
        val k = (p * notes.size).toInt().coerceAtMost(notes.size - 1)
        val f = notes[k]
        sin(TWO_PI * f * t) * 0.7f + sin(TWO_PI * f * 2f * t) * 0.2f
    }

    private fun track(data: ShortArray, loop: Boolean): AudioTrack {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(if (loop) AudioAttributes.CONTENT_TYPE_MUSIC else AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(data, 0, data.size)
        if (loop) t.setLoopPoints(0, data.size, -1)
        return t
    }

    private fun reg(id: Int, data: ShortArray, copies: Int = 3) {
        sfx[id] = Array(copies) { track(data, false) }
    }

    private fun build() {
        reg(SHOOT, gen(0.09f, 0.30f) { t, _ -> sw(1100f, 500f, 0.09f, t) * 0.6f + sw(2200f, 900f, 0.09f, t) * 0.2f }, 4)
        reg(HIT, gen(0.06f, 0.35f) { t, _ -> noise() * 0.5f + sw(300f, 150f, 0.06f, t) * 0.5f }, 4)
        reg(KILL, gen(0.18f, 0.45f) { t, p -> noise() * (1f - p) * 0.6f + sw(260f, 60f, 0.18f, t) * 0.7f }, 4)
        reg(GEM, gen(0.10f, 0.30f) { t, _ -> sw(900f, 1500f, 0.1f, t) }, 3)
        reg(LEVEL, arp(floatArrayOf(523f, 659f, 784f, 1047f), 0.55f, 0.5f), 2)
        reg(DASH, gen(0.20f, 0.40f) { t, p -> noise() * 0.5f * sin(PI.toFloat() * p) + sw(200f, 700f, 0.2f, t) * 0.3f }, 2)
        reg(NOVA, gen(0.75f, 0.65f) { t, p -> sw(180f, 30f, 0.75f, t) * 0.8f + noise() * (1f - p) * 0.4f }, 2)
        reg(HURT, gen(0.25f, 0.50f) { t, _ -> sw(220f, 80f, 0.25f, t) * 0.7f + (if ((t * 40f).toInt() % 2 == 0) 0.2f else -0.2f) }, 2)
        reg(BOSS, gen(1.1f, 0.65f) { t, p -> sw(90f, 40f, 1.1f, t) * 0.7f + sw(93f, 43f, 1.1f, t) * 0.5f + noise() * 0.15f * (1f - p) }, 1)
        reg(CLICK, gen(0.04f, 0.35f) { t, _ -> sw(700f, 500f, 0.04f, t) }, 2)
        reg(WIN, arp(floatArrayOf(523f, 659f, 784f, 1047f, 1319f, 1568f), 1.2f, 0.5f), 1)
        reg(LOSE, arp(floatArrayOf(392f, 330f, 262f, 196f), 1.1f, 0.5f), 1)
        reg(HEAL, gen(0.25f, 0.35f) { t, _ -> sw(500f, 900f, 0.25f, t) * 0.6f + sw(750f, 1350f, 0.25f, t) * 0.3f }, 2)
        for (k in 0 until 3) music[k] = track(buildMusic(k), true).also { it.setVolume(0.45f) }
    }

    // ------------------------------------------------------------------ música

    private fun note(buf: FloatArray, start: Int, len: Int, f: Float, amp: Float, atk: Float, dec: Float, rel: Float) {
        val n = min(len, buf.size - start)
        if (n <= 0) return
        val w = TWO_PI * f / SR
        val relN = max(1f, rel * SR)
        for (i in 0 until n) {
            val t = i / SR.toFloat()
            val env = min(1f, t / max(atk, 0.001f)) * exp(-dec * t) * min(1f, (n - i) / relN)
            val ph = w * i
            buf[start + i] += amp * env * (sin(ph) + 0.35f * sin(2f * ph) + 0.12f * sin(3f * ph))
        }
    }

    private fun kick(buf: FloatArray, start: Int, amp: Float) {
        val n = (0.22f * SR).toInt()
        for (i in 0 until n) {
            if (start + i >= buf.size) break
            val t = i / SR.toFloat()
            buf[start + i] += amp * sin(TWO_PI * (110f * t - 330f * t * t)) * exp(-t * 14f)
        }
    }

    private fun hat(buf: FloatArray, start: Int, amp: Float) {
        val n = (0.05f * SR).toInt()
        for (i in 0 until n) {
            if (start + i >= buf.size) break
            val t = i / SR.toFloat()
            buf[start + i] += amp * noise() * exp(-t * 70f)
        }
    }

    private fun semi(f: Float, s: Int): Float = f * 2f.pow(s / 12f)

    private fun buildMusic(kind: Int): ShortArray {
        val bpm = when (kind) { 0 -> 72f; 1 -> 108f; else -> 126f }
        val beatS = (60f / bpm * SR).toInt()
        val bars = 8
        val total = bars * 4 * beatS
        val buf = FloatArray(total)
        val roots = if (kind == 2) floatArrayOf(110f, 87.31f, 73.42f, 82.41f) else floatArrayOf(110f, 87.31f, 130.81f, 98f)
        val minor = if (kind == 2) booleanArrayOf(true, false, true, false) else booleanArrayOf(true, false, false, false)
        val pat = intArrayOf(0, 2, 1, 2, 0, 2, 1, 2)
        for (b in 0 until bars) {
            val ch = b % 4
            val root = roots[ch]
            val tri = if (minor[ch]) intArrayOf(0, 3, 7) else intArrayOf(0, 4, 7)
            val start = b * 4 * beatS
            for (s in tri) note(buf, start, 4 * beatS, semi(root * 2f, s), 0.05f, 0.4f, 0f, 0.4f)
            if (kind >= 1) {
                for (k in 0 until 4) note(buf, start + k * beatS, beatS, root, 0.22f, 0.01f, 5f, 0.02f)
                for (k in 0 until 4) kick(buf, start + k * beatS, 0.35f)
                if (kind == 2) for (k in 0 until 4) hat(buf, start + k * beatS + beatS / 2, 0.06f)
                note(buf, start, beatS * 2, semi(root * 4f, tri[2] + 12), 0.05f, 0.01f, 3f, 0.05f)
                if (b % 2 == 0) note(buf, start + 2 * beatS, beatS * 2, semi(root * 4f, tri[1] + 12), 0.045f, 0.01f, 3f, 0.05f)
            } else {
                note(buf, start, 4 * beatS, root, 0.18f, 0.05f, 1.2f, 0.1f)
            }
            for (j in 0 until 8) {
                if (kind == 0 && j % 2 == 1) continue
                val f = semi(root * 4f, tri[pat[j]])
                note(buf, start + j * (beatS / 2), beatS, f, if (kind == 0) 0.05f else 0.065f, 0.005f, 7f, 0.03f)
            }
        }
        val dry = buf.copyOf()
        val delay = (beatS * 0.75f).toInt()
        for (i in 0 until total) buf[(i + delay) % total] += dry[i] * 0.32f
        var peak = 0.001f
        for (v in buf) peak = max(peak, abs(v))
        val scale = 0.85f / peak
        return ShortArray(total) { (buf[it] * scale * 32000f).toInt().coerceIn(-32000, 32000).toShort() }
    }
}
