package com.lumen.lastlight

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private const val ST_TITLE = 0
private const val ST_STORY = 1
private const val ST_STAGES = 2
private const val ST_SHOP = 3
private const val ST_CHARS = 4
private const val ST_SET = 5
private const val ST_PLAY = 6
private const val ST_LEVEL = 7
private const val ST_PAUSE = 8
private const val ST_RESULT = 9

private const val B_PLAY = 1
private const val B_SHOP = 2
private const val B_CHARS = 3
private const val B_SET = 4
private const val B_BACK = 5
private const val B_NEXT = 6
private const val B_RESUME = 7
private const val B_QUIT = 8
private const val B_RETRY = 9
private const val B_SFX = 10
private const val B_MUS = 11
private const val B_HAP = 12
private const val B_RESET = 13
private const val B_STAGE = 100
private const val B_BUY = 200
private const val B_CHAR = 300
private const val B_UP = 400

private const val WW = 1300f
private const val WH = 900f
private const val SH = 360f
private const val TAU = 6.2831855f

private val E_HP = floatArrayOf(6f, 3f, 7f, 32f, 12f)
private val E_SP = floatArrayOf(62f, 105f, 44f, 36f, 54f)
private val E_R = floatArrayOf(9f, 7f, 9f, 16f, 11f)
private val E_DMG = floatArrayOf(8f, 6f, 8f, 16f, 8f)
private val E_XP = intArrayOf(1, 1, 2, 6, 2)

private val C_CRIT = col(0xFFFFE066)
private val C_RED = col(0xFFFF5566)
private val C_GOLD = col(0xFFFFC04D)
private val GEM_COL = intArrayOf(col(0xFF6FE9FF), col(0xFF7CFFA0), col(0xFFC38BFF))

private class Btn(val id: Int, val r: RectF)

class GameView(ctx: Context, private val save: Save, private val audio: Audio) :
    SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    // ---------------------------------------------------------------- tela
    private var pw = 1
    private var ph = 1
    private var u = 3f
    private var SW = 800f
    @Volatile private var running = false
    private var thread: Thread? = null

    // ---------------------------------------------------------------- pintura
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tfBold: Typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    private val tfNorm: Typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    private val glowPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val cfCache = HashMap<Int, PorterDuffColorFilter>()
    private lateinit var glowBmp: Bitmap
    private val gSrc = Rect(0, 0, 64, 64)
    private val gDst = RectF()
    private val tmpR = RectF()
    private val pth = Path()
    private val darkPaint = Paint()
    private val darkMat = Matrix()
    private var darkShader: RadialGradient? = null
    private val menuGrad = arrayOfNulls<LinearGradient>(4)

    // ---------------------------------------------------------------- estado geral
    private var state = ST_TITLE
    private var fade = 1f
    private var tAnim = 0f
    private var pressedId = -1
    private val btns = ArrayList<Btn>()
    private var storyPage = 0
    private var confirmReset = false
    private val sfxT = FloatArray(Audio.COUNT)
    private val motes = FloatArray(70 * 4)

    // ---------------------------------------------------------------- partida
    private var realm = REALMS[0]
    private var stIdx = 0
    private var hero = 0
    private var elapsed = 0f
    private var spawnT = 1f
    private var swarmT = 22f
    private var nextBossAt = 0f
    private var bossCount = 0
    private var bossRef: Enemy? = null
    private var nextId = 1

    private var px = WW / 2
    private var py = WH / 2
    private var hp = 100f
    private var maxHp = 100f
    private var pSpeed = 115f
    private var dmg = 3f
    private var fireRate = 1.7f
    private var multi = 1
    private var pierce = 0
    private var magnetR = 55f
    private var lightR = 175f
    private var regen = 0f
    private var dashCdMax = 2.2f
    private var novaNeed = 30
    private var blades = 0
    private var crit = 0.05f
    private var aura = 0
    private var homing = true
    private var luck = 1f

    private var invuln = 0f
    private var dashT = 0f
    private var dashCd = 0f
    private var dashDx = 1f
    private var dashDy = 0f
    private var fireT = 0f
    private var faceX = 1f
    private var faceY = 0f
    private var bladeAng = 0f
    private var lvl = 1
    private var xp = 0
    private var xpNeed = 5
    private var pending = 0
    private var novaCharge = 0
    private var kills = 0
    private var runShards = 0
    private val upLv = IntArray(UPS.size)
    private val opts = IntArray(3)
    private var optN = 3

    private var joyId = -1
    private var joyBX = 0f
    private var joyBY = 0f
    private var joyX = 0f
    private var joyY = 0f
    private var wantDash = false
    private var wantNova = false

    private var camX = 0f
    private var camY = 0f
    private var shake = 0f
    private var hitFlash = 0f
    private var slow = 0f
    private var endTimer = 0f
    private var endWin = false
    private var hintT = 0f
    private var bannerT = 0f
    private var bannerText = ""
    private var darkMul = 1f

    private var resWin = false
    private var resScore = 0
    private var resKills = 0
    private var resTime = 0f
    private var resEarn = 0
    private var resStars = 0
    private var resBest = false

    private val enemies = ArrayList<Enemy>()
    private val bullets = ArrayList<Bullet>()
    private val ebullets = ArrayList<Bullet>()
    private val pickups = ArrayList<Pickup>()
    private val rings = ArrayList<Ring>()
    private val parts = Array(600) { Part() }
    private var partI = 0
    private val ftexts = Array(30) { FText() }
    private var ftI = 0
    private var props = FloatArray(0)

    private val q = ConcurrentLinkedQueue<TouchEv>()

    init {
        holder.addCallback(this)
        isFocusable = true
        buildGlow()
        for (i in 0 until 70) {
            motes[i * 4] = Random.nextFloat()
            motes[i * 4 + 1] = Random.nextFloat() * SH
            motes[i * 4 + 2] = 4f + Random.nextFloat() * 14f
            motes[i * 4 + 3] = Random.nextFloat() * TAU
        }
    }

    // ================================================================ ciclo de vida
    override fun surfaceCreated(h: SurfaceHolder) {
        running = true
        thread = Thread(this, "lumen-loop").also { it.start() }
        audio.music(musicFor())
    }

    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        pw = w; ph = hh
        u = hh / SH
        SW = w / u
    }

    override fun surfaceDestroyed(h: SurfaceHolder) {
        running = false
        try { thread?.join() } catch (e: InterruptedException) { }
        thread = null
    }

    fun pauseGame() {
        if (state == ST_PLAY) { setState(ST_PAUSE) }
    }

    fun onBack(): Boolean {
        when (state) {
            ST_PLAY -> setState(ST_PAUSE)
            ST_PAUSE -> setState(ST_PLAY)
            ST_LEVEL -> { }
            ST_TITLE -> return false
            ST_RESULT -> setState(ST_STAGES)
            else -> setState(ST_TITLE)
        }
        return true
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            var dt = (now - last) / 1_000_000_000f
            last = now
            if (dt > 0.05f) dt = 0.05f
            try {
                processInput()
                update(dt)
                if (holder.surface.isValid) {
                    val c = holder.lockHardwareCanvas()
                    if (c != null) {
                        try { render(c) } finally { holder.unlockCanvasAndPost(c) }
                    }
                }
            } catch (e: Exception) { }
            val spent = (System.nanoTime() - now) / 1_000_000
            if (spent < 8) try { Thread.sleep(8 - spent) } catch (e: InterruptedException) { }
        }
    }

    // ================================================================ entrada
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                q.add(TouchEv(0, e.getPointerId(i), e.getX(i), e.getY(i)))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) q.add(TouchEv(1, e.getPointerId(i), e.getX(i), e.getY(i)))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                q.add(TouchEv(2, e.getPointerId(i), e.getX(i), e.getY(i)))
            }
            MotionEvent.ACTION_CANCEL -> q.add(TouchEv(3, 0, 0f, 0f))
        }
        return true
    }

    private fun processInput() {
        while (true) {
            val e = q.poll() ?: break
            val x = e.x / u
            val y = e.y / u
            when (e.a) {
                0 -> inDown(e.id, x, y)
                1 -> inMove(e.id, x, y)
                2 -> inUp(e.id, x, y)
                else -> { joyId = -1; joyX = 0f; joyY = 0f; pressedId = -1 }
            }
        }
    }

    private fun dashX() = SW - 58f
    private fun dashY() = SH - 62f
    private fun novaX() = SW - 134f
    private fun novaY() = SH - 40f

    private fun inDown(id: Int, x: Float, y: Float) {
        if (state == ST_PLAY) {
            if (hypot(x - (SW - 24f), y - 24f) < 26f) { sfx(Audio.CLICK); setState(ST_PAUSE); return }
            if (hypot(x - dashX(), y - dashY()) < 40f) { wantDash = true; return }
            if (hypot(x - novaX(), y - novaY()) < 36f) { wantNova = true; return }
            if (joyId == -1 && x < SW * 0.55f) { joyId = id; joyBX = x; joyBY = y; joyX = 0f; joyY = 0f }
        } else {
            pressedId = hit(x, y)
        }
    }

    private fun inMove(id: Int, x: Float, y: Float) {
        if (id != joyId) return
        var dx = x - joyBX
        var dy = y - joyBY
        val d = hypot(dx, dy)
        val rad = 40f
        if (d > rad) {
            joyBX += dx / d * (d - rad)
            joyBY += dy / d * (d - rad)
            dx = x - joyBX
            dy = y - joyBY
        }
        joyX = dx / rad
        joyY = dy / rad
        if (hypot(joyX, joyY) < 0.12f) { joyX = 0f; joyY = 0f }
    }

    private fun inUp(id: Int, x: Float, y: Float) {
        if (id == joyId) { joyId = -1; joyX = 0f; joyY = 0f; return }
        if (state != ST_PLAY) {
            val h = hit(x, y)
            val pr = pressedId
            pressedId = -1
            if (h != -1 && h == pr) onButton(h)
        }
    }

    private fun hit(x: Float, y: Float): Int {
        for (i in btns.indices.reversed()) if (btns[i].r.contains(x, y)) return btns[i].id
        return -1
    }

    private fun setState(s: Int) {
        state = s
        fade = 0.8f
        joyId = -1; joyX = 0f; joyY = 0f
        pressedId = -1
        confirmReset = false
        btns.clear()
        audio.music(musicFor())
    }

    private fun musicFor(): Int = when (state) {
        ST_PLAY, ST_LEVEL, ST_PAUSE -> if (bossRef != null) 2 else 1
        else -> 0
    }

    private fun sfx(id: Int, gap: Float = 0f, vol: Float = 1f) {
        if (gap > 0f) {
            if (sfxT[id] > 0f) return
            sfxT[id] = gap
        }
        audio.play(id, vol)
    }

    private fun haptic() {
        if (save.hapticOn) post { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
    }

    private fun onButton(id: Int) {
        sfx(Audio.CLICK)
        when {
            id == B_PLAY -> setState(if (!save.storyDone) ST_STORY else ST_STAGES)
            id == B_SHOP -> setState(ST_SHOP)
            id == B_CHARS -> setState(ST_CHARS)
            id == B_SET -> setState(ST_SET)
            id == B_BACK -> setState(if (state == ST_RESULT) ST_STAGES else ST_TITLE)
            id == B_NEXT -> {
                storyPage++
                if (storyPage >= 4) { save.storyDone = true; storyPage = 0; setState(ST_STAGES) }
            }
            id == B_RESUME -> setState(ST_PLAY)
            id == B_QUIT -> finishRun(false)
            id == B_RETRY -> startRun(stIdx)
            id == B_SFX -> { save.sfxOn = !save.sfxOn }
            id == B_MUS -> { save.musicOn = !save.musicOn; audio.refresh() }
            id == B_HAP -> { save.hapticOn = !save.hapticOn }
            id == B_RESET -> {
                if (confirmReset) {
                    save.reset(); confirmReset = false; audio.refresh()
                } else confirmReset = true
            }
            id >= B_UP -> {
                val k = id - B_UP
                if (k in 0 until optN) {
                    applyUp(opts[k])
                    sfx(Audio.LEVEL)
                    pending--
                    if (pending > 0) openLevelUp() else setState(ST_PLAY)
                }
            }
            id >= B_CHAR -> {
                val k = id - B_CHAR
                if (save.charMask and (1 shl k) != 0) save.charSel = k
                else if (save.shards >= HEROES[k].cost) {
                    save.shards -= HEROES[k].cost
                    save.charMask = save.charMask or (1 shl k)
                    save.charSel = k
                    sfx(Audio.LEVEL)
                }
            }
            id >= B_BUY -> {
                val k = id - B_BUY
                val l = save.perm(k)
                val cost = permCost(l)
                if (l < PERM_MAX && save.shards >= cost) {
                    save.shards -= cost
                    save.setPerm(k, l + 1)
                    sfx(Audio.GEM)
                }
            }
            id >= B_STAGE -> {
                val k = id - B_STAGE
                if (k <= save.unlocked) startRun(k)
            }
        }
    }

    private fun permCost(l: Int) = 30 * (l + 1) + 12 * l * l

    // ================================================================ utilidades
    private fun rr(a: Float, b: Float) = a + (b - a) * Random.nextFloat()
    private fun rnd() = Random.nextFloat()

    private fun mix(a: Int, b: Int, t: Float): Int {
        val ar = Color.red(a); val ag = Color.green(a); val ab = Color.blue(a)
        val br = Color.red(b); val bg = Color.green(b); val bb = Color.blue(b)
        return Color.rgb((ar + (br - ar) * t).toInt(), (ag + (bg - ag) * t).toInt(), (ab + (bb - ab) * t).toInt())
    }

    private fun withA(c: Int, a: Float): Int = (c and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    private fun spark(x: Float, y: Float, vx: Float, vy: Float, life: Float, size: Float, color: Int, drag: Float = 2f) {
        val p = parts[partI]
        partI = (partI + 1) % parts.size
        p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = life; p.max = life
        p.size = size; p.color = color; p.drag = drag
    }

    private fun burst(x: Float, y: Float, n: Int, color: Int, spd: Float, life: Float, size: Float) {
        for (i in 0 until n) {
            val a = rr(0f, TAU)
            val s = rr(spd * 0.3f, spd)
            spark(x, y, cos(a) * s, sin(a) * s, rr(life * 0.5f, life), rr(size * 0.6f, size), color)
        }
    }

    private fun floatText(x: Float, y: Float, s: String, color: Int, size: Float) {
        val f = ftexts[ftI]
        ftI = (ftI + 1) % ftexts.size
        f.x = x; f.y = y; f.text = s; f.color = color; f.size = size; f.life = 0.8f
    }

    private fun banner(s: String) { bannerText = s; bannerT = 2.6f }

    // ================================================================ início de partida
    private fun startRun(i: Int) {
        stIdx = i
        realm = REALMS[i]
        hero = save.charSel
        enemies.clear(); bullets.clear(); ebullets.clear(); pickups.clear(); rings.clear()
        for (p in parts) p.life = 0f
        for (f in ftexts) f.life = 0f
        elapsed = 0f; spawnT = 1f; swarmT = 20f; bossCount = 0; bossRef = null
        nextBossAt = 75f
        val pHp = 1f + 0.10f * save.perm(0)
        val pDmg = 1f + 0.08f * save.perm(1)
        val pSpd = 1f + 0.05f * save.perm(2)
        magnetR = 55f * (1f + 0.12f * save.perm(3))
        lightR = 175f * (1f + 0.08f * save.perm(4))
        luck = 1f + 0.12f * save.perm(5)

        maxHp = 100f * pHp
        pSpeed = 115f * pSpd
        dmg = 3.2f * pDmg
        fireRate = 1.7f; multi = 1; pierce = 0; blades = 0; homing = true
        when (hero) {
            1 -> { blades = 3; fireRate = 1.0f; dmg = 3.8f * pDmg; pSpeed *= 1.12f; homing = false }
            2 -> { multi = 3; pierce = 1; dmg = 2.6f * pDmg; fireRate = 1.4f; maxHp *= 0.85f; homing = false }
        }
        hp = maxHp
        regen = 0f; dashCdMax = 2.2f; novaNeed = 30; crit = 0.05f; aura = 0
        invuln = 0f; dashT = 0f; dashCd = 0f; fireT = 0.3f
        lvl = 1; xp = 0; xpNeed = 5; pending = 0; novaCharge = 0
        kills = 0; runShards = 0
        for (k in upLv.indices) upLv[k] = 0
        px = WW / 2; py = WH / 2 + 60f
        camX = px - SW / 2; camY = py - SH / 2
        shake = 0f; hitFlash = 0f; slow = 0f; endTimer = 0f; endWin = false
        darkMul = 1f; bannerT = 0f
        hintT = if (!save.tutorialDone) 8f else 0f
        save.tutorialDone = true
        wantDash = false; wantNova = false
        // cenário
        val rg = Random(i * 977 + 13)
        val n = 90
        props = FloatArray(n * 5)
        for (k in 0 until n) {
            props[k * 5] = rg.nextFloat() * WW
            props[k * 5 + 1] = 30f + rg.nextFloat() * (WH - 30f)
            props[k * 5 + 2] = 8f + rg.nextFloat() * 16f
            props[k * 5 + 3] = rg.nextInt(2).toFloat()
            props[k * 5 + 4] = rg.nextFloat() * 6f
        }
        val rgb = realm.dark and 0x00FFFFFF
        darkShader = RadialGradient(
            0f, 0f, 1f,
            intArrayOf(rgb, (0x55 shl 24) or rgb, (0xD2 shl 24) or rgb),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        setState(ST_PLAY)
        banner(realm.name)
    }

    private fun applyUp(i: Int) {
        upLv[i]++
        when (i) {
            0 -> dmg *= 1.22f
            1 -> fireRate *= 1.18f
            2 -> multi += 1
            3 -> pierce += 1
            4 -> pSpeed *= 1.10f
            5 -> { maxHp += 25f; hp = min(maxHp, hp + 35f) }
            6 -> magnetR *= 1.4f
            7 -> blades += 1
            8 -> regen += 0.9f
            9 -> novaNeed = max(8, (novaNeed * 0.8f).toInt())
            10 -> dashCdMax *= 0.8f
            11 -> crit += 0.1f
            12 -> aura += 1
        }
    }

    private fun openLevelUp() {
        val pool = ArrayList<Int>()
        for (i in UPS.indices) if (upLv[i] < UPS[i].max) pool.add(i)
        pool.shuffle()
        optN = min(3, pool.size)
        if (optN == 0) { hp = min(maxHp, hp + 30f); pending = 0; setState(ST_PLAY); return }
        for (k in 0 until optN) opts[k] = pool[k]
        setState(ST_LEVEL)
    }

    // ================================================================ simulação
    private fun update(dt: Float) {
        tAnim += dt
        if (fade > 0f) fade = max(0f, fade - dt * 2.5f)
        for (s in sfxT.indices) if (sfxT[s] > 0f) sfxT[s] -= dt
        for (i in 0 until 70) {
            motes[i * 4 + 1] -= motes[i * 4 + 2] * dt
            if (motes[i * 4 + 1] < -4f) { motes[i * 4 + 1] = SH + 4f; motes[i * 4] = rnd() }
        }
        if (state == ST_PLAY) updatePlay(dt)
    }

    private fun updatePlay(dt0: Float) {
        var dt = dt0
        if (slow > 0f) { slow -= dt0; dt *= 0.35f }
        elapsed += dt
        bannerT -= dt0
        hintT -= dt0
        shake = max(0f, shake - dt0 * 30f)
        hitFlash = max(0f, hitFlash - dt0 * 2.5f)
        invuln -= dt
        dashCd -= dt
        val alive = hp > 0f
        val boss = bossRef

        if (endTimer > 0f) {
            endTimer -= dt0
            if (endTimer <= 0f) { finishRun(endWin); return }
        }

        // --- movimento
        if (alive) {
            val m = hypot(joyX, joyY)
            if (m > 0.01f) { faceX = joyX / m; faceY = joyY / m }
            if (wantDash && dashCd <= 0f && dashT <= 0f) {
                wantDash = false
                dashT = 0.18f; dashCd = dashCdMax
                dashDx = if (m > 0.01f) joyX / m else faceX
                dashDy = if (m > 0.01f) joyY / m else faceY
                invuln = max(invuln, 0.35f)
                sfx(Audio.DASH)
                burst(px, py, 10, mix(hero().color, Color.WHITE, 0.3f), 120f, 0.4f, 5f)
            }
            wantDash = false
            if (dashT > 0f) {
                dashT -= dt
                px += dashDx * 380f * dt
                py += dashDy * 380f * dt
                spark(px, py, 0f, 0f, 0.35f, 9f, hero().color, 3f)
            } else {
                px += joyX * pSpeed * dt
                py += joyY * pSpeed * dt
                if (m > 0.3f && rnd() < 0.5f) spark(px - faceX * 6f, py - faceY * 6f, rr(-10f, 10f), rr(-10f, 10f), 0.4f, 4f, hero().color)
            }
            px = px.coerceIn(12f, WW - 12f)
            py = py.coerceIn(12f, WH - 12f)
            hp = min(maxHp, hp + regen * dt)

            if (wantNova && novaCharge >= novaNeed) {
                wantNova = false
                useNova()
            }
            wantNova = false

            fireT -= dt
            if (fireT <= 0f) {
                val tg = nearest(240f)
                if (tg != null) { shoot(tg); fireT = 1f / fireRate }
            }
        } else { wantDash = false; wantNova = false }

        // --- câmera
        val tx = if (WW <= SW) (WW - SW) / 2 else (px - SW / 2).coerceIn(0f, WW - SW)
        val ty = (py - SH / 2).coerceIn(0f, WH - SH)
        camX += (tx - camX) * min(1f, dt * 8f)
        camY += (ty - camY) * min(1f, dt * 8f)

        // --- diretor de inimigos
        if (alive && endTimer <= 0f) director(dt)
        darkMul = if (boss != null && boss.kind == 2) 0.82f else 1f

        // --- lâminas orbitais
        bladeAng += 3.2f * dt
        if (blades > 0 && alive) {
            for (k in 0 until blades) {
                val a = bladeAng + k * TAU / blades
                val bx = px + cos(a) * 46f
                val by = py + sin(a) * 46f
                for (i in 0 until enemies.size) {
                    val e = enemies[i]
                    if (!e.alive) continue
                    if (e.bladeT <= 0f && hypot(e.x - bx, e.y - by) < e.r + 8f) {
                        e.bladeT = 0.3f
                        hurtEnemy(e, dmg * 0.9f, false, cos(a + 1.57f), sin(a + 1.57f), 90f)
                    }
                }
                for (i in 0 until ebullets.size) {
                    val b = ebullets[i]
                    if (b.alive && hypot(b.x - bx, b.y - by) < 11f) {
                        b.alive = false
                        burst(b.x, b.y, 3, Color.WHITE, 60f, 0.25f, 3f)
                    }
                }
            }
        }

        // --- inimigos
        for (i in 0 until enemies.size) {
            val e = enemies[i]
            if (!e.alive) continue
            e.flash -= dt; e.bladeT -= dt; e.auraT -= dt; e.t += dt
            val dx = px - e.x
            val dy = py - e.y
            val d = hypot(dx, dy) + 0.001f
            val nx = dx / d
            val ny = dy / d
            if (!e.boss) e.ang = atan2(dy, dx)
            if (e.boss) {
                updateBoss(e, dt)
            } else {
                when (e.type) {
                    0 -> {
                        val w = sin(e.t * 3f + e.id) * 0.5f
                        e.x += (nx - ny * w) * e.speed * dt; e.y += (ny + nx * w) * e.speed * dt
                    }
                    2 -> {
                        if (d > 135f) { e.x += nx * e.speed * dt; e.y += ny * e.speed * dt }
                        else if (d < 95f) { e.x -= nx * e.speed * dt; e.y -= ny * e.speed * dt }
                        else { e.x += -ny * e.speed * 0.6f * dt; e.y += nx * e.speed * 0.6f * dt }
                        e.cd -= dt
                        if (e.cd <= 0f && d < 270f) {
                            e.cd = 2.3f + rnd()
                            fireB(e.x, e.y, e.ang, 115f, e.dmg, realm.tint)
                        }
                    }
                    else -> { e.x += nx * e.speed * dt; e.y += ny * e.speed * dt }
                }
            }
            // empurrão
            e.x += e.kx * dt; e.y += e.ky * dt
            val f = min(1f, dt * 8f)
            e.kx -= e.kx * f; e.ky -= e.ky * f
            e.x = e.x.coerceIn(e.r, WW - e.r)
            e.y = e.y.coerceIn(e.r, WH - e.r)
            // aura
            if (aura > 0 && e.auraT <= 0f && d < 38f + aura * 7f + e.r) {
                e.auraT = 0.5f
                hurtEnemy(e, 1f + aura * 0.9f + dmg * 0.25f, false, -nx, -ny, 10f)
            }
            // contato
            if (alive && d < e.r + 8f) hurtPlayer(e.dmg)
        }
        // separação
        val ne = min(enemies.size, 130)
        for (i in 0 until ne) {
            val a = enemies[i]
            if (!a.alive) continue
            for (j in i + 1 until ne) {
                val b = enemies[j]
                if (!b.alive) continue
                val dx = b.x - a.x
                val dy = b.y - a.y
                val rr2 = (a.r + b.r) * 0.8f
                if (dx * dx + dy * dy < rr2 * rr2) {
                    val d = hypot(dx, dy) + 0.01f
                    val push = (rr2 - d) * 0.5f
                    if (!a.boss) { a.x -= dx / d * push; a.y -= dy / d * push }
                    if (!b.boss) { b.x += dx / d * push; b.y += dy / d * push }
                }
            }
        }

        // --- projéteis do jogador
        for (i in 0 until bullets.size) {
            val b = bullets[i]
            if (!b.alive) continue
            val tg = b.target
            if (homing && tg != null && tg.alive) {
                val want = atan2(tg.y - b.y, tg.x - b.x)
                val cur = atan2(b.vy, b.vx)
                var diff = want - cur
                while (diff > 3.1416f) diff -= TAU
                while (diff < -3.1416f) diff += TAU
                val na = cur + diff.coerceIn(-5f * dt, 5f * dt)
                val sp = hypot(b.vx, b.vy)
                b.vx = cos(na) * sp; b.vy = sin(na) * sp
            }
            b.x += b.vx * dt; b.y += b.vy * dt
            b.life -= dt
            if (b.life <= 0f || b.x < 0f || b.y < 0f || b.x > WW || b.y > WH) { b.alive = false; continue }
            for (j in 0 until enemies.size) {
                val e = enemies[j]
                if (!e.alive) continue
                if (hypot(e.x - b.x, e.y - b.y) < e.r + b.r) {
                    var seen = false
                    for (k in 0 until b.nHit) if (b.ids[k] == e.id) seen = true
                    if (seen) continue
                    if (b.nHit < b.ids.size) { b.ids[b.nHit] = e.id; b.nHit++ }
                    val sp = hypot(b.vx, b.vy) + 0.01f
                    hurtEnemy(e, b.dmg, b.crit, b.vx / sp, b.vy / sp, 70f)
                    b.pierce--
                    if (b.pierce < 0) { b.alive = false; break }
                }
            }
        }
        // --- projéteis inimigos
        for (i in 0 until ebullets.size) {
            val b = ebullets[i]
            if (!b.alive) continue
            b.x += b.vx * dt; b.y += b.vy * dt
            b.life -= dt
            if (b.life <= 0f || b.x < -10f || b.y < -10f || b.x > WW + 10f || b.y > WH + 10f) { b.alive = false; continue }
            if (alive && hypot(b.x - px, b.y - py) < b.r + 7f && invuln <= 0f) {
                b.alive = false
                hurtPlayer(b.dmg)
            }
        }

        // --- coletáveis
        for (i in 0 until pickups.size) {
            val p = pickups[i]
            p.t += dt
            val dx = px - p.x
            val dy = py - p.y
            val d = hypot(dx, dy) + 0.001f
            if (alive && (d < magnetR || p.mag)) {
                p.mag = true
                val sp = 160f + p.t * 40f + (300f - min(d, 300f)) * 0.5f
                p.x += dx / d * sp * dt; p.y += dy / d * sp * dt
            }
            if (alive && d < 11f) {
                when (p.type) {
                    0, 1, 2 -> { gainXp(p.value); sfx(Audio.GEM, 0.05f, 0.6f) }
                    3 -> { hp = min(maxHp, hp + 18f); sfx(Audio.HEAL); floatText(px, py - 14f, "+18", col(0xFF6BFF9A), 10f) }
                    else -> { runShards += p.value; sfx(Audio.GEM, 0.05f, 0.8f) }
                }
                p.t = -999f
            }
        }

        // --- partículas
        for (p in parts) {
            if (p.life <= 0f) continue
            p.life -= dt
            p.x += p.vx * dt; p.y += p.vy * dt
            val f = max(0f, 1f - p.drag * dt)
            p.vx *= f; p.vy *= f
        }
        for (f in ftexts) if (f.life > 0f) { f.life -= dt; f.y -= 22f * dt }
        var ri = rings.size - 1
        while (ri >= 0) { rings[ri].life -= dt; if (rings[ri].life <= 0f) rings.removeAt(ri); ri-- }

        // --- limpeza
        cleanup()
        if (pickups.size > 260) pickups.removeAt(0)

        if (pending > 0 && state == ST_PLAY && hp > 0f && endTimer <= 0f) openLevelUp()
    }

    private fun cleanup() {
        var i = enemies.size - 1
        while (i >= 0) {
            if (!enemies[i].alive) { enemies[i] = enemies[enemies.size - 1]; enemies.removeAt(enemies.size - 1) }
            i--
        }
        i = bullets.size - 1
        while (i >= 0) {
            if (!bullets[i].alive) { bullets[i] = bullets[bullets.size - 1]; bullets.removeAt(bullets.size - 1) }
            i--
        }
        i = ebullets.size - 1
        while (i >= 0) {
            if (!ebullets[i].alive) { ebullets[i] = ebullets[ebullets.size - 1]; ebullets.removeAt(ebullets.size - 1) }
            i--
        }
        i = pickups.size - 1
        while (i >= 0) {
            if (pickups[i].t < -900f) { pickups[i] = pickups[pickups.size - 1]; pickups.removeAt(pickups.size - 1) }
            i--
        }
    }

    private fun hero() = HEROES[hero]

    private fun gainXp(v: Int) {
        xp += v
        while (xp >= xpNeed) {
            xp -= xpNeed
            lvl++
            xpNeed = 5 + (lvl - 1) * 4 + ((lvl - 1) * (lvl - 1)) / 3
            pending++
        }
    }

    private fun nearest(range: Float): Enemy? {
        var best: Enemy? = null
        var bd = range
        for (i in 0 until enemies.size) {
            val e = enemies[i]
            if (!e.alive) continue
            val d = hypot(e.x - px, e.y - py) - e.r
            if (d < bd) { bd = d; best = e }
        }
        return best
    }

    private fun shoot(t: Enemy) {
        val base = atan2(t.y - py, t.x - px)
        val step = if (hero == 2) 0.2f else 0.15f
        for (k in 0 until multi) {
            val a = base + (k - (multi - 1) / 2f) * step
            val b = Bullet()
            val isCrit = rnd() < crit
            b.x = px; b.y = py
            b.vx = cos(a) * 310f; b.vy = sin(a) * 310f
            b.dmg = dmg * (if (isCrit) 2f else 1f)
            b.crit = isCrit
            b.pierce = pierce
            b.life = 1.3f
            b.r = if (hero == 2) 5f else 5.5f
            b.color = if (isCrit) C_CRIT else hero().color
            b.target = if (homing) t else null
            bullets.add(b)
        }
        sfx(Audio.SHOOT, 0.06f, 0.7f)
    }

    private fun fireB(x: Float, y: Float, a: Float, sp: Float, d: Float, color: Int) {
        if (ebullets.size > 260) return
        val b = Bullet()
        b.enemy = true; b.x = x; b.y = y
        b.vx = cos(a) * sp; b.vy = sin(a) * sp
        b.dmg = d; b.life = 6f; b.r = 4.5f; b.color = color
        ebullets.add(b)
    }

    private fun ringShot(x: Float, y: Float, n: Int, sp: Float, d: Float, rot: Float, color: Int) {
        for (k in 0 until n) fireB(x, y, rot + k * TAU / n, sp, d, color)
    }

    private fun useNova() {
        novaCharge = 0
        sfx(Audio.NOVA)
        shake = 10f
        rings.add(Ring(px, py, 200f, 0.6f, hero().color))
        burst(px, py, 40, hero().color, 260f, 0.7f, 6f)
        val d = 10f + dmg * 5f
        for (i in 0 until enemies.size) {
            val e = enemies[i]
            if (!e.alive) continue
            val dx = e.x - px
            val dy = e.y - py
            val dist = hypot(dx, dy) + 0.01f
            if (dist < 200f + e.r) hurtEnemy(e, if (e.boss) d * 2f else d, false, dx / dist, dy / dist, 420f)
        }
        for (b in ebullets) if (hypot(b.x - px, b.y - py) < 210f) b.alive = false
        invuln = max(invuln, 0.5f)
    }

    private fun hurtEnemy(e: Enemy, d: Float, isCrit: Boolean, ax: Float, ay: Float, kb: Float) {
        if (!e.alive) return
        e.hp -= d
        e.flash = 0.09f
        if (!e.boss) { e.kx += ax * kb; e.ky += ay * kb }
        burst(e.x, e.y, 2, if (isCrit) C_CRIT else realm.accent, 90f, 0.35f, 4f)
        if (isCrit || d >= 8f) floatText(e.x, e.y - e.r, d.toInt().toString(), if (isCrit) C_CRIT else Color.WHITE, if (isCrit) 12f else 9f)
        sfx(Audio.HIT, 0.05f, 0.6f)
        if (e.hp <= 0f) killEnemy(e)
    }

    private fun killEnemy(e: Enemy) {
        e.alive = false
        kills++
        burst(e.x, e.y, if (e.boss) 70 else 12, realm.tint, if (e.boss) 280f else 140f, 0.7f, if (e.boss) 9f else 5f)
        if (e.boss) { bossDown(e); return }
        val gt = if (e.xp >= 5) 2 else if (e.xp >= 2) 1 else 0
        pickups.add(Pickup(e.x, e.y, gt, e.xp))
        if (rnd() < 0.025f) pickups.add(Pickup(e.x + 6f, e.y, 3, 18))
        if (rnd() < 0.07f * luck) pickups.add(Pickup(e.x - 6f, e.y, 4, 1))
        novaCharge = min(novaNeed, novaCharge + 1)
        if (e.type == 4) for (k in 0 until 2) spawnEnemy(0, e.x + rr(-8f, 8f), e.y + rr(-8f, 8f), 0.6f)
        sfx(Audio.KILL, 0.04f, 0.7f)
    }

    private fun bossDown(e: Enemy) {
        bossCount++
        bossRef = null
        ebullets.clear()
        for (i in 0 until enemies.size) {
            val o = enemies[i]
            if (o.alive && o !== e) { o.alive = false; burst(o.x, o.y, 6, realm.tint, 120f, 0.5f, 4f) }
        }
        for (k in 0 until 14) pickups.add(Pickup(e.x + rr(-34f, 34f), e.y + rr(-34f, 34f), 4, 3 + stIdx))
        for (k in 0 until 6) pickups.add(Pickup(e.x + rr(-30f, 30f), e.y + rr(-30f, 30f), 2, 6))
        rings.add(Ring(e.x, e.y, 260f, 0.9f, realm.tint))
        shake = 16f; slow = 1.2f
        sfx(Audio.NOVA)
        if (stIdx < 3) {
            endTimer = 2.4f; endWin = true; invuln = 999f
            banner("O CHEFE CAIU!")
        } else {
            banner("CHEFE DERROTADO!")
            nextBossAt = elapsed + 70f
            audio.music(1)
        }
    }

    private fun hurtPlayer(d: Float) {
        if (invuln > 0f || hp <= 0f) return
        hp -= d
        invuln = 0.75f
        shake = max(shake, 6f)
        hitFlash = 1f
        burst(px, py, 10, C_RED, 150f, 0.5f, 4f)
        sfx(Audio.HURT, 0.1f)
        haptic()
        if (hp <= 0f) {
            hp = 0f
            endTimer = 1.6f; endWin = false; slow = 1.5f
            burst(px, py, 50, hero().color, 260f, 0.9f, 7f)
            sfx(Audio.LOSE)
        }
    }

    // ================================================================ diretor
    private fun director(dt: Float) {
        val boss = bossRef
        spawnT -= if (boss != null) dt * 0.35f else dt
        if (spawnT <= 0f) {
            spawnT = max(0.28f, 1.25f - elapsed * 0.0065f - stIdx * 0.09f)
            val n = 1 + (elapsed / 35f).toInt() + stIdx / 2
            val cap = 70 + stIdx * 12
            for (k in 0 until n) if (enemies.size < cap) spawnEnemy(pickType())
        }
        swarmT -= dt
        if (swarmT <= 0f && boss == null) {
            swarmT = 26f
            banner("ENXAME!")
            val side = Random.nextInt(4)
            val cnt = 10 + stIdx * 3
            for (k in 0 until cnt) {
                val off = rr(-90f, 90f)
                val hw = SW / 2 + 30f
                val hh = SH / 2 + 30f
                val x = when (side) { 0 -> px - hw; 1 -> px + hw; else -> px + off * 4f }
                val y = when (side) { 2 -> py - hh; 3 -> py + hh; else -> py + off * 2f }
                spawnEnemy(1, x.coerceIn(10f, WW - 10f), y.coerceIn(10f, WH - 10f))
            }
        }
        if (boss == null) {
            if (stIdx < 3) {
                if (elapsed >= realm.time && bossCount == 0) spawnBoss(stIdx, 1f)
            } else if (elapsed >= nextBossAt) {
                spawnBoss(bossCount % 3, 1f + bossCount * 0.6f)
                nextBossAt = elapsed + 9999f
            }
        }
    }

    private fun pickType(): Int {
        val t = elapsed
        val w = floatArrayOf(
            10f,
            3f + t / 20f,
            if (t > 15f) 3f + t / 30f + stIdx else 0f,
            if (t > 30f) 1f + t / 50f else 0f,
            if (t > 20f) 2f + t / 40f else 0f
        )
        var sum = 0f
        for (v in w) sum += v
        var r = rnd() * sum
        for (i in w.indices) { r -= w[i]; if (r <= 0f) return i }
        return 0
    }

    private fun spawnEnemy(type: Int, x0: Float = Float.NaN, y0: Float = Float.NaN, hs: Float = 1f) {
        var x = x0
        var y = y0
        if (x.isNaN()) {
            var ok = false
            for (tries in 0 until 8) {
                val hw = SW / 2 + 24f
                val hh = SH / 2 + 24f
                when (Random.nextInt(4)) {
                    0 -> { x = px - hw; y = py + rr(-hh, hh) }
                    1 -> { x = px + hw; y = py + rr(-hh, hh) }
                    2 -> { x = px + rr(-hw, hw); y = py - hh }
                    else -> { x = px + rr(-hw, hw); y = py + hh }
                }
                x = x.coerceIn(10f, WW - 10f); y = y.coerceIn(10f, WH - 10f)
                if (kotlin.math.abs(x - px) > SW / 2 + 8f || kotlin.math.abs(y - py) > SH / 2 + 8f) { ok = true; break }
            }
            if (!ok) return
        }
        val e = Enemy()
        e.id = nextId++
        e.type = type
        e.x = x; e.y = y
        val hpMul = (1f + elapsed / 55f + stIdx * 0.45f) * hs
        e.maxHp = E_HP[type] * hpMul; e.hp = e.maxHp
        e.speed = E_SP[type] * (1f + stIdx * 0.04f) * rr(0.9f, 1.1f)
        e.r = E_R[type]; e.dmg = E_DMG[type] * (1f + stIdx * 0.15f)
        e.xp = E_XP[type]
        e.cd = rr(0.5f, 2f)
        enemies.add(e)
    }

    private fun spawnBoss(kind: Int, scale: Float) {
        val e = Enemy()
        e.id = nextId++
        e.boss = true; e.kind = kind; e.type = 5
        val hpBase = floatArrayOf(800f, 1400f, 2400f)[kind]
        e.maxHp = hpBase * scale; e.hp = e.maxHp
        e.r = floatArrayOf(30f, 28f, 36f)[kind]
        e.dmg = 18f; e.speed = 30f
        val a = rr(0f, TAU)
        e.x = (px + cos(a) * 220f).coerceIn(e.r, WW - e.r)
        e.y = (py + sin(a) * 160f).coerceIn(e.r, WH - e.r)
        e.cd = 2f; e.cd2 = 1.5f; e.cd3 = 4f
        enemies.add(e)
        bossRef = e
        banner("CHEFE: " + (if (stIdx == 3) REALMS[kind].boss else realm.boss))
        sfx(Audio.BOSS)
        shake = 10f
        audio.music(2)
    }

    private fun updateBoss(b: Enemy, dt: Float) {
        val ratio = b.hp / b.maxHp
        val phase = if (ratio > 0.66f) 1 else if (ratio > 0.33f) 2 else 3
        val dx = px - b.x
        val dy = py - b.y
        val d = hypot(dx, dy) + 0.001f
        val ang = atan2(dy, dx)
        when (b.kind) {
            0 -> {
                when (b.state) {
                    0 -> {
                        val sp = 26f + phase * 8f
                        b.x += dx / d * sp * dt; b.y += dy / d * sp * dt
                        b.cd -= dt
                        if (b.cd <= 0f) { b.state = 1; b.st = 0.7f; b.ang = ang }
                    }
                    1 -> {
                        b.st -= dt; b.ang = ang
                        if (b.st <= 0f) { b.state = 2; b.st = 0.5f }
                    }
                    else -> {
                        b.st -= dt
                        b.x += cos(b.ang) * 300f * dt; b.y += sin(b.ang) * 300f * dt
                        spark(b.x, b.y, rr(-20f, 20f), rr(-20f, 20f), 0.5f, 10f, realm.tint)
                        if (b.st <= 0f) {
                            b.state = 0; b.cd = 3.4f - phase * 0.5f
                            ringShot(b.x, b.y, 12 + phase * 4, 90f, 9f, rr(0f, 6f), realm.tint)
                            shake = 6f
                        }
                    }
                }
                b.cd2 -= dt
                if (b.cd2 <= 0f) { b.cd2 = 4.2f; ringShot(b.x, b.y, 10 + phase * 4, 80f, 8f, b.t, realm.tint) }
                if (phase >= 2) {
                    b.cd3 -= dt
                    if (b.cd3 <= 0f) {
                        b.cd3 = 5f
                        for (k in 0 until phase) spawnEnemy(0, b.x + rr(-20f, 20f), b.y + rr(-20f, 20f), 0.7f)
                    }
                }
            }
            1 -> {
                val sp = 34f
                if (d > 175f) { b.x += dx / d * sp * dt; b.y += dy / d * sp * dt }
                else if (d < 115f) { b.x -= dx / d * sp * dt; b.y -= dy / d * sp * dt }
                else { b.x += -dy / d * sp * 0.6f * dt; b.y += dx / d * sp * 0.6f * dt }
                b.cd2 -= dt
                if (b.cd2 <= 0f) {
                    b.cd2 = 0.2f - phase * 0.03f
                    b.st += 0.42f
                    val arms = 2 + phase
                    for (k in 0 until arms) fireB(b.x, b.y, b.st + k * TAU / arms, 85f, 8f, realm.tint)
                }
                b.cd -= dt
                if (b.cd <= 0f) {
                    b.cd = 3.6f
                    for (k in -1..1) fireB(b.x, b.y, ang + k * 0.22f, 135f, 10f, realm.accent)
                }
                b.cd3 -= dt
                if (b.cd3 <= 0f) {
                    b.cd3 = 7f
                    for (k in 0 until 3 + phase * 2) {
                        val a = k * TAU / (3 + phase * 2)
                        spawnEnemy(1, b.x + cos(a) * 34f, b.y + sin(a) * 34f, 0.8f)
                    }
                }
            }
            else -> {
                if (b.state == 0 && d > 110f) {
                    val sp = 22f + phase * 4f
                    b.x += dx / d * sp * dt; b.y += dy / d * sp * dt
                }
                when (b.state) {
                    0 -> {
                        b.cd -= dt
                        if (b.cd <= 0f) {
                            b.cd = 2.6f - phase * 0.35f
                            b.cnt++
                            when (b.cnt % 3) {
                                0 -> ringShot(b.x, b.y, 16 + phase * 6, 95f, 9f, b.t, realm.tint)
                                1 -> { val n = 5 + phase * 2; for (k in 0 until n) fireB(b.x, b.y, ang + (k - (n - 1) / 2f) * 0.2f, 140f, 10f, realm.accent) }
                                else -> { b.state = 1; b.st = 0.6f; b.ang = ang }
                            }
                        }
                    }
                    1 -> { b.st -= dt; if (b.st <= 0f) { b.state = 2; b.st = 0.5f } }
                    else -> {
                        b.st -= dt
                        b.x += cos(b.ang) * 320f * dt; b.y += sin(b.ang) * 320f * dt
                        spark(b.x, b.y, rr(-20f, 20f), rr(-20f, 20f), 0.5f, 12f, realm.tint)
                        if (b.st <= 0f) b.state = 0
                    }
                }
                if (phase >= 2) {
                    b.cd2 -= dt
                    if (b.cd2 <= 0f) {
                        b.cd2 = 0.28f
                        fireB(b.x, b.y, b.t * 2.2f, 80f, 8f, realm.tint)
                        fireB(b.x, b.y, b.t * 2.2f + 3.1416f, 80f, 8f, realm.tint)
                    }
                }
                if (phase >= 3) {
                    b.cd3 -= dt
                    if (b.cd3 <= 0f) { b.cd3 = 6f; for (k in 0 until 2) spawnEnemy(2, b.x + rr(-30f, 30f), b.y + rr(-30f, 30f), 0.8f) }
                }
            }
        }
        b.x = b.x.coerceIn(b.r, WW - b.r)
        b.y = b.y.coerceIn(b.r, WH - b.r)
    }

    // ================================================================ fim de partida
    private fun finishRun(win: Boolean) {
        resWin = win
        resKills = kills
        resTime = elapsed
        val endless = stIdx == 3
        resScore = kills * 10 + elapsed.toInt() * 4 + bossCount * 1500 + (if (win && !endless) 1500 else 0)
        var earn = runShards
        if (win && !endless) earn += 60 + stIdx * 40
        if (endless) earn += (elapsed / 6f).toInt()
        resStars = 0
        if (win && !endless) {
            val r = hp / maxHp
            resStars = if (r >= 0.7f) 3 else if (r >= 0.35f) 2 else 1
            val old = save.stars(stIdx)
            if (resStars > old) { earn += (resStars - old) * 30; save.setStars(stIdx, resStars) }
            save.unlocked = max(save.unlocked, stIdx + 1)
        }
        resBest = resScore > save.best(stIdx)
        if (resBest) save.setBest(stIdx, resScore)
        resEarn = earn
        save.shards += earn
        bossRef = null
        setState(ST_RESULT)
        sfx(if (win) Audio.WIN else Audio.LOSE)
    }

    // ================================================================ desenho: base
    private val STORY = arrayOf(
        "Há muito tempo, o mundo era sustentado por uma única chama: a Lâmpada da Aurora.",
        "Então a Umbra despertou. Criaturas de sombra que devoram toda luz por onde passam.",
        "Você é uma centelha, a última Guardiã. Atravesse os reinos e reacenda a Lâmpada.",
        "Arraste à esquerda para mover. Os ataques são automáticos. DASH desvia, NOVA limpa a tela."
    )

    private fun buildGlow() {
        glowBmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val cv = Canvas(glowBmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            32f, 32f, 32f,
            intArrayOf(col(0xFFFFFFFF), col(0x80FFFFFF), col(0x00FFFFFF)),
            floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(32f, 32f, 32f, p)
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float = 1f) {
        val key = color or col(0xFF000000)
        val cf = cfCache.getOrPut(key) { PorterDuffColorFilter(key, PorterDuff.Mode.SRC_IN) }
        glowPaint.colorFilter = cf
        glowPaint.alpha = (a.coerceIn(0f, 1f) * 255f).toInt()
        gDst.set(x - r, y - r, x + r, y + r)
        c.drawBitmap(glowBmp, gSrc, gDst, glowPaint)
    }

    private fun fill(color: Int) { fp.style = Paint.Style.FILL; fp.shader = null; fp.color = color }
    private fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int) { fill(color); c.drawCircle(x, y, r, fp) }
    private fun ringS(c: Canvas, x: Float, y: Float, r: Float, w: Float, color: Int) {
        fp.style = Paint.Style.STROKE; fp.strokeWidth = w; fp.shader = null; fp.color = color
        c.drawCircle(x, y, r, fp)
        fp.style = Paint.Style.FILL
    }
    private fun rrect(c: Canvas, x: Float, y: Float, w: Float, h: Float, rad: Float, color: Int) {
        fill(color); tmpR.set(x, y, x + w, y + h); c.drawRoundRect(tmpR, rad, rad, fp)
    }
    private fun rrectS(c: Canvas, x: Float, y: Float, w: Float, h: Float, rad: Float, sw: Float, color: Int) {
        fp.style = Paint.Style.STROKE; fp.strokeWidth = sw; fp.shader = null; fp.color = color
        tmpR.set(x, y, x + w, y + h); c.drawRoundRect(tmpR, rad, rad, fp)
        fp.style = Paint.Style.FILL
    }
    private fun strokePath(c: Canvas, w: Float, color: Int) {
        fp.style = Paint.Style.STROKE; fp.strokeWidth = w; fp.shader = null; fp.color = color
        c.drawPath(pth, fp)
        fp.style = Paint.Style.FILL
    }
    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        fp.style = Paint.Style.STROKE; fp.strokeWidth = w; fp.shader = null; fp.color = color
        c.drawLine(x1, y1, x2, y2, fp)
        fp.style = Paint.Style.FILL
    }
    private fun diamond(c: Canvas, x: Float, y: Float, s: Float, color: Int) {
        pth.reset()
        pth.moveTo(x, y - s); pth.lineTo(x + s * 0.7f, y); pth.lineTo(x, y + s); pth.lineTo(x - s * 0.7f, y); pth.close()
        fill(color); c.drawPath(pth, fp)
    }

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        align: Paint.Align = Paint.Align.CENTER, bold: Boolean = true, maxW: Float = 100000f, spacing: Float = 0f
    ) {
        tp.typeface = if (bold) tfBold else tfNorm
        tp.textAlign = align
        tp.color = color
        tp.letterSpacing = spacing
        var sz = size
        tp.textSize = sz
        while (tp.measureText(s) > maxW && sz > 6f) { sz -= 0.5f; tp.textSize = sz }
        c.drawText(s, x, y, tp)
    }

    private fun wrap(s: String, size: Float, maxW: Float): List<String> {
        tp.typeface = tfNorm; tp.textSize = size; tp.letterSpacing = 0f
        val out = ArrayList<String>()
        var ln = ""
        for (w in s.split(" ")) {
            val t = if (ln.isEmpty()) w else "$ln $w"
            if (tp.measureText(t) > maxW && ln.isNotEmpty()) { out.add(ln); ln = w } else ln = t
        }
        if (ln.isNotEmpty()) out.add(ln)
        return out
    }

    private fun panel(c: Canvas, x: Float, y: Float, w: Float, h: Float, accent: Int, fillA: Float = 0.82f) {
        rrect(c, x, y, w, h, 12f, withA(col(0xFF05070D), fillA))
        rrect(c, x, y, w, h, 12f, withA(accent, 0.10f))
        rrectS(c, x, y, w, h, 12f, 1.6f, withA(accent, 0.8f))
    }

    private fun button(
        c: Canvas, id: Int, x: Float, y: Float, w: Float, h: Float, label: String, accent: Int,
        size: Float = 15f, enabled: Boolean = true
    ) {
        btns.add(Btn(id, RectF(x, y, x + w, y + h)))
        val pr = pressedId == id
        rrect(c, x, y, w, h, 10f, withA(col(0xFF05070D), 0.85f))
        rrect(c, x, y, w, h, 10f, if (enabled) withA(accent, if (pr) 0.5f else 0.18f) else col(0x22FFFFFF))
        rrectS(c, x, y, w, h, 10f, 1.6f, if (enabled) accent else col(0x55FFFFFF))
        text(c, label, x + w / 2, y + h / 2 + size * 0.35f, size, if (enabled) Color.WHITE else col(0xFF8890A0), maxW = w - 12f)
    }

    private fun backBtn(c: Canvas) = button(c, B_BACK, 16f, SH - 46f, 110f, 34f, "VOLTAR", Color.WHITE, 13f)

    private fun shardsHud(c: Canvas) {
        val s = save.shards.toString()
        diamond(c, SW - 64f, 22f, 7f, C_GOLD)
        text(c, s, SW - 52f, 28f, 16f, Color.WHITE, Paint.Align.LEFT)
    }

    private fun fmt(t: Float): String {
        val s = max(0, t.toInt())
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    private fun starRow(c: Canvas, cx: Float, y: Float, n: Int, s: Float) {
        for (k in 0 until 3) {
            val x = cx + (k - 1) * s * 2.6f
            if (k < n) { glow(c, x, y, s * 2.2f, C_GOLD, 0.5f); diamond(c, x, y, s, C_GOLD) }
            else diamond(c, x, y, s, col(0xFF2A3040))
        }
    }

    // ================================================================ render principal
    private fun render(c: Canvas) {
        c.drawColor(Color.BLACK)
        c.save()
        c.scale(u, u)
        when (state) {
            ST_TITLE -> drawTitle(c)
            ST_STORY -> drawStory(c)
            ST_STAGES -> drawStages(c)
            ST_SHOP -> drawShop(c)
            ST_CHARS -> drawChars(c)
            ST_SET -> drawSettings(c)
            else -> {
                drawWorld(c)
                if (state != ST_RESULT) drawHud(c)
                if (state == ST_LEVEL) drawLevel(c)
                if (state == ST_PAUSE) drawPause(c)
                if (state == ST_RESULT) drawResult(c)
            }
        }
        if (fade > 0f) { fill(withA(Color.BLACK, fade)); c.drawRect(0f, 0f, SW, SH, fp) }
        c.restore()
    }

    // ================================================================ menus
    private fun drawMenuBg(c: Canvas, ri: Int) {
        val r = REALMS[ri]
        val g = menuGrad[ri] ?: LinearGradient(0f, 0f, 0f, SH, r.ground, r.bg, Shader.TileMode.CLAMP).also { menuGrad[ri] = it }
        fp.style = Paint.Style.FILL; fp.shader = g
        c.drawRect(0f, 0f, SW, SH, fp)
        fp.shader = null
        for (layer in 0 until 3) {
            pth.reset()
            pth.moveTo(0f, SH)
            var x = 0f
            while (x <= SW + 20f) {
                val y = SH * 0.66f + layer * 26f + sin(x * 0.011f + layer * 1.7f + tAnim * 0.05f * (layer + 1)) * 18f + sin(x * 0.031f + layer) * 8f
                pth.lineTo(x, y)
                x += 20f
            }
            pth.lineTo(SW, SH); pth.close()
            fill(mix(r.bg, Color.BLACK, 0.4f + layer * 0.2f))
            c.drawPath(pth, fp)
        }
        for (i in 0 until 70) {
            val mx = motes[i * 4] * SW + sin(tAnim * 0.6f + motes[i * 4 + 3]) * 10f
            glow(c, mx, motes[i * 4 + 1], 4f + motes[i * 4 + 2] * 0.3f, r.accent, 0.55f)
        }
    }

    private fun drawTitle(c: Canvas) {
        btns.clear()
        val ri = min(save.unlocked, 2)
        val r = REALMS[ri]
        drawMenuBg(c, ri)
        val cx = SW / 2
        val pulse = 1f + 0.06f * sin(tAnim * 2f)
        glow(c, cx, 100f, 210f * pulse, r.accent, 0.32f)
        glow(c, cx, 100f, 95f * pulse, col(0xFFFFE9A8), 0.5f)
        for (k in 0 until 14) {
            val a = tAnim * 0.15f + k * TAU / 14f
            line(c, cx + cos(a) * 46f, 100f + sin(a) * 46f, cx + cos(a) * 190f, 100f + sin(a) * 190f, 1.6f, withA(col(0xFFFFE9A8), 0.10f))
        }
        for (k in 0 until 4) {
            val a = k * 1.5708f
            text(c, "LUMEN", cx + cos(a) * 2f, 118f + sin(a) * 2f, 64f, withA(r.accent, 0.35f), spacing = 0.12f)
        }
        text(c, "LUMEN", cx, 118f, 64f, Color.WHITE, spacing = 0.12f)
        text(c, "A  ÚLTIMA  LUZ", cx, 146f, 15f, r.accent, spacing = 0.3f)
        button(c, B_PLAY, cx - 105f, 172f, 210f, 46f, "JOGAR", C_GOLD, 20f)
        button(c, B_SHOP, cx - 188f, 228f, 120f, 34f, "LOJA DE LUZ", r.accent, 12f)
        button(c, B_CHARS, cx - 60f, 228f, 120f, 34f, "GUARDIÕES", r.accent, 12f)
        button(c, B_SET, cx + 68f, 228f, 120f, 34f, "AJUSTES", r.accent, 12f)
        shardsHud(c)
        text(c, "v1.0", 12f, SH - 10f, 9f, col(0x88FFFFFF), Paint.Align.LEFT, false)
    }

    private fun drawStory(c: Canvas) {
        btns.clear()
        drawMenuBg(c, 0)
        val cx = SW / 2
        glow(c, cx, 90f, 160f + 8f * sin(tAnim * 2f), col(0xFFFFE9A8), 0.35f)
        circle(c, cx, 90f, 11f, Color.WHITE)
        val lines = wrap(STORY[storyPage.coerceIn(0, 3)], 17f, min(SW - 80f, 560f))
        var y = 170f
        for (l in lines) { text(c, l, cx, y, 17f, Color.WHITE, bold = false); y += 26f }
        for (k in 0 until 4) circle(c, cx + (k - 1.5f) * 16f, 258f, 3.5f, if (k == storyPage) C_GOLD else col(0x55FFFFFF))
        button(c, B_NEXT, cx - 90f, 280f, 180f, 40f, if (storyPage >= 3) "COMEÇAR" else "CONTINUAR", C_GOLD, 15f)
    }

    private fun drawStages(c: Canvas) {
        btns.clear()
        drawMenuBg(c, min(save.unlocked, 3))
        text(c, "ESCOLHA O REINO", SW / 2, 38f, 22f, Color.WHITE, spacing = 0.1f)
        shardsHud(c)
        val m = 24f
        val gap = 12f
        val cw = (SW - m * 2 - gap * 3) / 4
        val ch = 218f
        val y = 60f
        for (i in 0 until 4) {
            val x = m + i * (cw + gap)
            val r = REALMS[i]
            val open = i <= save.unlocked
            btns.add(Btn(B_STAGE + i, RectF(x, y, x + cw, y + ch)))
            val pr = pressedId == B_STAGE + i
            rrect(c, x, y, cw, ch, 12f, withA(col(0xFF05070D), 0.88f))
            if (open) rrect(c, x, y, cw, ch, 12f, withA(r.accent, if (pr) 0.32f else 0.12f))
            rrectS(c, x, y, cw, ch, 12f, 1.8f, if (open) r.accent else col(0x44FFFFFF))
            val ox = x + cw / 2
            val oy = y + 50f
            if (open) {
                glow(c, ox, oy, 62f + 4f * sin(tAnim * 2f + i), r.accent, 0.6f)
                glow(c, ox, oy, 28f, Color.WHITE, 0.7f)
                circle(c, ox, oy, 12f, mix(r.accent, Color.WHITE, 0.6f))
            } else {
                circle(c, ox, oy, 14f, col(0xFF1B202B))
                rrect(c, ox - 7f, oy - 3f, 14f, 11f, 2f, col(0xFF5A6070))
                ringS(c, ox, oy - 5f, 5f, 2f, col(0xFF5A6070))
            }
            text(c, r.name, ox, y + 106f, 13f, if (open) Color.WHITE else col(0xFF7A8090), maxW = cw - 12f)
            text(c, r.sub, ox, y + 122f, 9.5f, col(0xFFA0A8B8), bold = false, maxW = cw - 10f)
            if (open) {
                if (i < 3) starRow(c, ox, y + 146f, save.stars(i), 5f)
                else text(c, "MODO INFINITO", ox, y + 150f, 11f, r.accent)
                text(c, "Recorde: ${save.best(i)}", ox, y + 172f, 11f, col(0xFFD0D6E4), bold = false)
                text(c, "TOQUE PARA JOGAR", ox, y + 200f, 11f, r.accent, spacing = 0.05f)
            } else {
                text(c, "BLOQUEADO", ox, y + 160f, 12f, col(0xFF8A90A0))
                text(c, "Derrote o chefe anterior", ox, y + 180f, 9.5f, col(0xFF6A7080), bold = false, maxW = cw - 10f)
            }
        }
        backBtn(c)
    }

    private fun drawShop(c: Canvas) {
        btns.clear()
        drawMenuBg(c, 1)
        text(c, "LOJA DE LUZ", SW / 2, 36f, 22f, Color.WHITE, spacing = 0.1f)
        text(c, "Melhorias permanentes para todas as partidas", SW / 2, 54f, 11f, col(0xFFA0A8B8), bold = false)
        shardsHud(c)
        val m = 24f
        val gap = 12f
        val cw = (SW - m * 2 - gap * 2) / 3
        val ch = 104f
        for (i in 0 until 6) {
            val x = m + (i % 3) * (cw + gap)
            val y = 70f + (i / 3) * (ch + 10f)
            val d = PERMS[i]
            val l = save.perm(i)
            val maxed = l >= PERM_MAX
            val cost = permCost(l)
            val can = !maxed && save.shards >= cost
            btns.add(Btn(B_BUY + i, RectF(x, y, x + cw, y + ch)))
            panel(c, x, y, cw, ch, d.color)
            if (pressedId == B_BUY + i) rrect(c, x, y, cw, ch, 12f, withA(d.color, 0.25f))
            glow(c, x + 26f, y + 30f, 30f, d.color, 0.7f)
            diamond(c, x + 26f, y + 30f, 11f, d.color)
            text(c, d.name, x + 52f, y + 26f, 14f, Color.WHITE, Paint.Align.LEFT, maxW = cw - 60f)
            text(c, d.desc, x + 52f, y + 42f, 10f, col(0xFFB0B8C8), Paint.Align.LEFT, false, cw - 60f)
            for (k in 0 until PERM_MAX) {
                rrect(c, x + 14f + k * ((cw - 28f) / PERM_MAX), y + 56f, (cw - 28f) / PERM_MAX - 3f, 7f, 2f, if (k < l) d.color else col(0xFF252B3A))
            }
            if (maxed) text(c, "NÍVEL MÁXIMO", x + cw / 2, y + 90f, 12f, C_GOLD)
            else {
                diamond(c, x + cw / 2 - 22f, y + 85f, 7f, if (can) C_GOLD else col(0xFF6A7080))
                text(c, cost.toString(), x + cw / 2 - 11f, y + 91f, 15f, if (can) Color.WHITE else col(0xFFFF7A8A), Paint.Align.LEFT)
                text(c, if (can) "COMPRAR" else "", x + cw - 12f, y + 91f, 11f, d.color, Paint.Align.RIGHT)
            }
        }
        backBtn(c)
    }

    private fun drawChars(c: Canvas) {
        btns.clear()
        drawMenuBg(c, 2)
        text(c, "GUARDIÕES", SW / 2, 36f, 22f, Color.WHITE, spacing = 0.1f)
        shardsHud(c)
        val m = 24f
        val gap = 12f
        val cw = (SW - m * 2 - gap * 2) / 3
        val ch = 232f
        val y = 52f
        for (i in 0 until 3) {
            val x = m + i * (cw + gap)
            val h = HEROES[i]
            val owned = save.charMask and (1 shl i) != 0
            val sel = save.charSel == i
            btns.add(Btn(B_CHAR + i, RectF(x, y, x + cw, y + ch)))
            panel(c, x, y, cw, ch, if (sel) C_GOLD else h.color)
            if (pressedId == B_CHAR + i) rrect(c, x, y, cw, ch, 12f, withA(h.color, 0.25f))
            val ox = x + cw / 2
            val oy = y + 56f
            glow(c, ox, oy, 66f, h.color, if (owned) 0.7f else 0.25f)
            val bc = if (owned) mix(h.color, Color.WHITE, 0.55f) else col(0xFF3A4050)
            circle(c, ox, oy, 15f, bc)
            circle(c, ox, oy, 10f, if (owned) Color.WHITE else col(0xFF4A5060))
            if (i == 1) for (k in 0 until 3) {
                val a = tAnim * 3.2f + k * TAU / 3
                glow(c, ox + cos(a) * 34f, oy + sin(a) * 34f, 14f, h.color, 0.9f)
                circle(c, ox + cos(a) * 34f, oy + sin(a) * 34f, 4f, Color.WHITE)
            }
            if (i == 2) for (k in -1..1) {
                val a = -0.5f + k * 0.35f
                line(c, ox + cos(a) * 20f, oy + sin(a) * 20f, ox + cos(a) * 42f, oy + sin(a) * 42f, 3f, withA(h.color, 0.9f))
            }
            text(c, h.name, ox, y + 112f, 20f, Color.WHITE)
            text(c, h.title, ox, y + 128f, 11f, h.color)
            val ls = h.desc.split("|")
            for (k in ls.indices) text(c, ls[k], ox, y + 152f + k * 14f, 10.5f, col(0xFFC0C8D8), bold = false, maxW = cw - 12f)
            if (sel) text(c, "SELECIONADA", ox, y + 208f, 13f, C_GOLD, spacing = 0.05f)
            else if (owned) text(c, "TOQUE PARA ESCOLHER", ox, y + 208f, 11f, h.color)
            else {
                val ok = save.shards >= h.cost
                diamond(c, ox - 26f, y + 204f, 7f, C_GOLD)
                text(c, h.cost.toString(), ox - 14f, y + 210f, 15f, if (ok) Color.WHITE else col(0xFFFF7A8A), Paint.Align.LEFT)
                text(c, if (ok) "TOQUE PARA DESBLOQUEAR" else "CRISTAIS INSUFICIENTES", ox, y + 224f, 9f, col(0xFFA0A8B8), bold = false)
            }
        }
        backBtn(c)
    }

    private fun drawSettings(c: Canvas) {
        btns.clear()
        drawMenuBg(c, 0)
        text(c, "AJUSTES", SW / 2, 40f, 22f, Color.WHITE, spacing = 0.1f)
        val w = 280f
        val x = SW / 2 - w / 2
        button(c, B_SFX, x, 66f, w, 38f, "EFEITOS SONOROS: " + (if (save.sfxOn) "LIGADO" else "DESLIGADO"), REALMS[0].accent, 13f)
        button(c, B_MUS, x, 112f, w, 38f, "MÚSICA: " + (if (save.musicOn) "LIGADA" else "DESLIGADA"), REALMS[0].accent, 13f)
        button(c, B_HAP, x, 158f, w, 38f, "VIBRAÇÃO: " + (if (save.hapticOn) "LIGADA" else "DESLIGADA"), REALMS[0].accent, 13f)
        button(c, B_RESET, x, 214f, w, 38f, if (confirmReset) "TOQUE DE NOVO PARA CONFIRMAR" else "APAGAR PROGRESSO", C_RED, 12f)
        text(c, "Lumen: A Última Luz  •  O progresso é salvo automaticamente", SW / 2, SH - 14f, 10f, col(0x99FFFFFF), bold = false)
        backBtn(c)
    }

    // ================================================================ mundo
    private fun inView(x: Float, y: Float, m: Float) = x > camX - m && x < camX + SW + m && y > camY - m && y < camY + SH + m

    private fun drawWorld(c: Canvas) {
        val r = realm
        c.drawColor(r.bg)
        var sx = 0f
        var sy = 0f
        if (shake > 0f) { sx = rr(-shake, shake) * 0.5f; sy = rr(-shake, shake) * 0.5f }
        val ox = -camX + sx
        val oy = -camY + sy
        val alive = hp > 0f

        c.save()
        c.translate(ox, oy)
        fill(r.ground); c.drawRect(0f, 0f, WW, WH, fp)
        // grade
        fp.style = Paint.Style.STROKE; fp.strokeWidth = 1f; fp.color = withA(r.accent, 0.07f); fp.shader = null
        var gx = (camX / 80f).toInt() * 80f
        while (gx < camX + SW + 80f) { if (gx >= 0f && gx <= WW) c.drawLine(gx, max(0f, camY), gx, min(WH, camY + SH), fp); gx += 80f }
        var gy = (camY / 80f).toInt() * 80f
        while (gy < camY + SH + 80f) { if (gy >= 0f && gy <= WH) c.drawLine(max(0f, camX), gy, min(WW, camX + SW), gy, fp); gy += 80f }
        fp.style = Paint.Style.FILL
        ringS(c, WW / 2, WH / 2, 70f, 2f, withA(r.accent, 0.25f))
        ringS(c, WW / 2, WH / 2, 110f, 1.5f, withA(r.accent, 0.14f))
        drawProps(c)
        fp.style = Paint.Style.STROKE; fp.strokeWidth = 5f; fp.color = withA(r.accent, 0.55f)
        c.drawRect(0f, 0f, WW, WH, fp)
        fp.style = Paint.Style.FILL

        // inimigos (corpos)
        for (i in 0 until enemies.size) {
            val e = enemies[i]
            if (!e.alive || !inView(e.x, e.y, 70f)) continue
            if (e.boss) drawBoss(c, e) else drawEnemy(c, e)
        }
        drawPlayer(c)
        c.restore()

        // escuridão com luz do jogador
        val ds = darkShader
        if (ds != null) {
            val lr = lightR * darkMul * (1f + 0.015f * sin(tAnim * 7f))
            darkMat.setScale(lr, lr)
            darkMat.postTranslate(px - camX + sx, py - camY + sy)
            ds.setLocalMatrix(darkMat)
            darkPaint.shader = ds
            c.drawRect(0f, 0f, SW, SH, darkPaint)
        }

        // luzes e efeitos (por cima da escuridão)
        c.save()
        c.translate(ox, oy)
        if (alive) {
            glow(c, px, py, 38f, hero().color, 0.85f)
            glow(c, px, py, 16f, Color.WHITE, 0.9f)
            if (aura > 0) ringS(c, px, py, 38f + aura * 7f, 1.5f, withA(col(0xFFFF9F43), 0.35f + 0.15f * sin(tAnim * 6f)))
        }
        glow(c, WW / 2, WH / 2, 60f + 6f * sin(tAnim * 2f), r.accent, 0.5f)
        for (i in 0 until pickups.size) {
            val p = pickups[i]
            if (!inView(p.x, p.y, 20f)) continue
            val bob = sin(tAnim * 4f + p.x) * 1.5f
            when (p.type) {
                0, 1, 2 -> {
                    val gc = GEM_COL[p.type]
                    glow(c, p.x, p.y + bob, 11f + p.type * 3f, gc, 0.8f)
                    diamond(c, p.x, p.y + bob, 3.6f + p.type * 1.5f, mix(gc, Color.WHITE, 0.5f))
                }
                3 -> {
                    glow(c, p.x, p.y + bob, 14f, col(0xFFFF6B8B), 0.8f)
                    circle(c, p.x - 2.5f, p.y + bob - 1f, 3.2f, col(0xFFFF8FA8))
                    circle(c, p.x + 2.5f, p.y + bob - 1f, 3.2f, col(0xFFFF8FA8))
                    pth.reset(); pth.moveTo(p.x - 5.6f, p.y + bob); pth.lineTo(p.x + 5.6f, p.y + bob); pth.lineTo(p.x, p.y + bob + 6.5f); pth.close()
                    fill(col(0xFFFF8FA8)); c.drawPath(pth, fp)
                }
                else -> {
                    glow(c, p.x, p.y + bob, 14f, C_GOLD, 0.8f)
                    diamond(c, p.x, p.y + bob, 5f, col(0xFFFFE9A8))
                }
            }
        }
        for (i in 0 until enemies.size) {
            val e = enemies[i]
            if (!e.alive || !inView(e.x, e.y, 70f)) continue
            val fa = if (e.boss) atan2(py - e.y, px - e.x) else e.ang
            val sepx = -sin(fa) * e.r * (if (e.boss) 0.34f else 0.28f)
            val sepy = cos(fa) * e.r * (if (e.boss) 0.34f else 0.28f)
            val exx = e.x + cos(fa) * e.r * 0.3f
            val eyy = e.y + sin(fa) * e.r * 0.3f
            val gr = 5f + e.r * (if (e.boss) 0.45f else 0.35f)
            glow(c, exx + sepx, eyy + sepy, gr, realm.tint, 0.9f)
            glow(c, exx - sepx, eyy - sepy, gr, realm.tint, 0.9f)
            circle(c, exx + sepx, eyy + sepy, if (e.boss) 2.6f else 1.4f, Color.WHITE)
            circle(c, exx - sepx, eyy - sepy, if (e.boss) 2.6f else 1.4f, Color.WHITE)
            if (e.boss && e.state == 1) {
                val a = 0.35f + 0.35f * sin(tAnim * 30f)
                line(c, e.x, e.y, e.x + cos(e.ang) * 260f, e.y + sin(e.ang) * 260f, 6f, withA(col(0xFFFF4040), a))
            }
        }
        for (i in 0 until ebullets.size) {
            val b = ebullets[i]
            if (!b.alive || !inView(b.x, b.y, 14f)) continue
            glow(c, b.x, b.y, 14f, b.color, 0.9f)
            circle(c, b.x, b.y, 3.2f, Color.WHITE)
        }
        for (i in 0 until bullets.size) {
            val b = bullets[i]
            if (!b.alive) continue
            glow(c, b.x, b.y, 17f, b.color, 0.9f)
            circle(c, b.x, b.y, 3.3f, Color.WHITE)
        }
        if (blades > 0 && alive) {
            for (k in 0 until blades) {
                val a = bladeAng + k * TAU / blades
                val bx = px + cos(a) * 46f
                val by = py + sin(a) * 46f
                glow(c, bx, by, 20f, hero().color, 0.9f)
                diamond(c, bx, by, 6f, Color.WHITE)
            }
        }
        for (rg in rings) {
            val k = rg.life / rg.max
            ringS(c, rg.x, rg.y, rg.maxR * (1f - k), 4f * k + 1f, withA(rg.color, k))
            glow(c, rg.x, rg.y, rg.maxR * (1f - k) * 1.1f + 4f, rg.color, 0.25f * k)
        }
        for (p in parts) {
            if (p.life <= 0f) continue
            val k = p.life / p.max
            glow(c, p.x, p.y, p.size * (0.5f + k), p.color, k)
        }
        for (f in ftexts) {
            if (f.life <= 0f) continue
            text(c, f.text, f.x, f.y, f.size, withA(f.color, min(1f, f.life * 2f)))
        }
        c.restore()

        if (hitFlash > 0f) { fill(withA(C_RED, hitFlash * 0.3f)); c.drawRect(0f, 0f, SW, SH, fp) }
        if (alive && hp / maxHp < 0.3f && state == ST_PLAY) {
            fill(withA(C_RED, 0.07f + 0.06f * sin(tAnim * 8f))); c.drawRect(0f, 0f, SW, SH, fp)
        }
    }

    private fun drawProps(c: Canvas) {
        val r = realm
        val n = props.size / 5
        for (k in 0 until n) {
            val x = props[k * 5]
            val y = props[k * 5 + 1]
            val s = props[k * 5 + 2]
            if (x < camX - 50f || x > camX + SW + 50f || y < camY - 70f || y > camY + SH + 50f) continue
            when (stIdx) {
                0 -> {
                    pth.reset()
                    pth.moveTo(x, y - s * 2.4f); pth.lineTo(x - s * 0.9f, y - s * 0.6f); pth.lineTo(x + s * 0.9f, y - s * 0.6f); pth.close()
                    pth.moveTo(x, y - s * 1.6f); pth.lineTo(x - s * 1.1f, y); pth.lineTo(x + s * 1.1f, y); pth.close()
                    fill(mix(r.ground, Color.BLACK, 0.45f)); c.drawPath(pth, fp)
                    strokePath(c, 1f, withA(r.accent, 0.25f))
                }
                1 -> {
                    pth.reset()
                    pth.moveTo(x, y - s * 2.4f); pth.lineTo(x + s * 0.6f, y - s * 0.8f); pth.lineTo(x, y); pth.lineTo(x - s * 0.6f, y - s * 0.8f); pth.close()
                    fill(withA(r.accent, 0.16f)); c.drawPath(pth, fp)
                    strokePath(c, 1.2f, withA(r.accent, 0.5f))
                }
                2 -> {
                    rrect(c, x - s * 0.35f, y - s * 2f, s * 0.7f, s * 2f, 1f, mix(r.ground, Color.BLACK, 0.4f))
                    pth.reset(); pth.moveTo(x, y - s * 2.5f); pth.lineTo(x + s * 0.35f, y - s * 2f); pth.lineTo(x - s * 0.35f, y - s * 2f); pth.close()
                    fill(withA(r.accent, 0.5f)); c.drawPath(pth, fp)
                    ringS(c, x, y, s * 0.9f, 1.2f, withA(r.accent, 0.3f))
                }
                else -> {
                    ringS(c, x, y, s * 0.9f, 1.4f, withA(r.accent, 0.3f))
                    ringS(c, x, y, s * 0.4f, 1.2f, withA(r.accent, 0.2f))
                    diamond(c, x, y, s * 0.3f, withA(r.accent, 0.4f))
                }
            }
        }
    }

    private fun drawPlayer(c: Canvas) {
        if (hp <= 0f) return
        fill(withA(Color.BLACK, 0.3f)); tmpR.set(px - 9f, py + 7f, px + 9f, py + 12f); c.drawOval(tmpR, fp)
        val blink = invuln > 0f && invuln < 900f && ((tAnim * 24f).toInt() % 2 == 0)
        if (blink) return
        val hc = hero().color
        val bob = sin(tAnim * 5f) * 1.2f
        for (k in 0 until 6) {
            val a = tAnim * 1.5f + k * TAU / 6f
            line(c, px + cos(a) * 12f, py + bob + sin(a) * 12f, px + cos(a) * 16f, py + bob + sin(a) * 16f, 1.6f, withA(hc, 0.8f))
        }
        circle(c, px, py + bob, 9f, mix(hc, Color.WHITE, 0.55f))
        circle(c, px, py + bob, 6f, Color.WHITE)
        val ex = faceX * 2.5f
        val ey = faceY * 2f
        circle(c, px - 2.6f + ex, py - 1f + ey + bob, 1.4f, col(0xFF2A2A40))
        circle(c, px + 2.6f + ex, py - 1f + ey + bob, 1.4f, col(0xFF2A2A40))
    }

    private fun drawEnemy(c: Canvas, e: Enemy) {
        val tint = realm.tint
        fill(withA(Color.BLACK, 0.3f)); tmpR.set(e.x - e.r, e.y + e.r * 0.6f, e.x + e.r, e.y + e.r * 1.15f); c.drawOval(tmpR, fp)
        val body = if (e.flash > 0f) Color.WHITE else mix(col(0xFF140D1E), tint, 0.14f)
        when (e.type) {
            0 -> {
                val yy = e.y + sin(e.t * 6f) * 1.5f
                circle(c, e.x, yy, e.r, body)
                ringS(c, e.x, yy, e.r, 1.6f, tint)
            }
            1 -> {
                c.save(); c.rotate(e.ang * 57.29578f, e.x, e.y)
                pth.reset()
                pth.moveTo(e.x + e.r * 1.6f, e.y); pth.lineTo(e.x, e.y + e.r * 0.8f); pth.lineTo(e.x - e.r * 1.2f, e.y); pth.lineTo(e.x, e.y - e.r * 0.8f); pth.close()
                fill(body); c.drawPath(pth, fp); strokePath(c, 1.5f, tint)
                c.restore()
            }
            2 -> {
                c.save(); c.rotate(e.ang * 57.29578f, e.x, e.y)
                pth.reset()
                pth.moveTo(e.x + e.r * 1.3f, e.y); pth.lineTo(e.x - e.r, e.y + e.r * 0.95f); pth.lineTo(e.x - e.r * 0.4f, e.y); pth.lineTo(e.x - e.r, e.y - e.r * 0.95f); pth.close()
                fill(body); c.drawPath(pth, fp); strokePath(c, 1.5f, tint)
                c.restore()
            }
            3 -> {
                c.save(); c.rotate(e.t * 20f, e.x, e.y)
                rrect(c, e.x - e.r, e.y - e.r, e.r * 2, e.r * 2, 5f, body)
                rrectS(c, e.x - e.r, e.y - e.r, e.r * 2, e.r * 2, 5f, 2f, tint)
                c.restore()
                circle(c, e.x, e.y, e.r * 0.8f, body)
                ringS(c, e.x, e.y, e.r * 0.8f, 1.5f, withA(tint, 0.7f))
            }
            else -> {
                circle(c, e.x, e.y, e.r, body)
                ringS(c, e.x, e.y, e.r, 1.6f, tint)
                circle(c, e.x - e.r * 0.4f, e.y + e.r * 0.35f, e.r * 0.35f, withA(tint, 0.35f))
                circle(c, e.x + e.r * 0.4f, e.y + e.r * 0.35f, e.r * 0.35f, withA(tint, 0.35f))
            }
        }
    }

    private fun drawBoss(c: Canvas, e: Enemy) {
        val tint = realm.tint
        fill(withA(Color.BLACK, 0.35f)); tmpR.set(e.x - e.r, e.y + e.r * 0.65f, e.x + e.r, e.y + e.r * 1.25f); c.drawOval(tmpR, fp)
        val n = intArrayOf(8, 6, 12)[e.kind]
        val body = if (e.flash > 0f) Color.WHITE else mix(col(0xFF140D1E), tint, 0.16f)
        for (k in 0 until n) {
            val a = e.t * 0.6f + k * TAU / n
            pth.reset()
            pth.moveTo(e.x + cos(a) * e.r * 1.5f, e.y + sin(a) * e.r * 1.5f)
            pth.lineTo(e.x + cos(a + 0.2f) * e.r * 0.95f, e.y + sin(a + 0.2f) * e.r * 0.95f)
            pth.lineTo(e.x + cos(a - 0.2f) * e.r * 0.95f, e.y + sin(a - 0.2f) * e.r * 0.95f)
            pth.close()
            fill(if (e.flash > 0f) Color.WHITE else mix(tint, Color.BLACK, 0.55f)); c.drawPath(pth, fp)
        }
        circle(c, e.x, e.y, e.r, body)
        ringS(c, e.x, e.y, e.r, 3f, tint)
        ringS(c, e.x, e.y, e.r * 0.65f, 1.5f, withA(tint, 0.6f))
    }

    // ================================================================ HUD
    private fun drawHud(c: Canvas) {
        val pad = 16f
        fill(col(0x66000000)); c.drawRect(0f, 0f, SW, 5f, fp)
        fill(realm.accent); c.drawRect(0f, 0f, SW * xp / xpNeed.toFloat(), 5f, fp)
        val ratio = (hp / maxHp).coerceIn(0f, 1f)
        rrect(c, pad, 14f, 140f, 12f, 6f, col(0xAA000000))
        if (ratio > 0f) rrect(c, pad, 14f, 140f * ratio, 12f, 6f, col(0xFFFF4D6D))
        rrectS(c, pad, 14f, 140f, 12f, 6f, 1.2f, col(0x88FFFFFF))
        text(c, "${hp.toInt()} / ${maxHp.toInt()}", pad + 70f, 23.5f, 9f, Color.WHITE)
        text(c, "NV $lvl", pad, 42f, 11f, Color.WHITE, Paint.Align.LEFT)
        text(c, REALMS[stIdx].name, pad, 55f, 9f, withA(Color.WHITE, 0.6f), Paint.Align.LEFT, false)

        val boss = bossRef
        val label = when {
            boss != null -> ""
            stIdx < 3 && bossCount == 0 -> "CHEFE EM " + fmt(realm.time - elapsed)
            else -> fmt(elapsed)
        }
        if (label.isNotEmpty()) text(c, label, SW / 2, 24f, 14f, Color.WHITE, spacing = 0.08f)
        if (boss != null) {
            val bw = 280f
            val bx = SW / 2 - bw / 2
            text(c, if (stIdx == 3) REALMS[boss.kind].boss else realm.boss, SW / 2, 22f, 12f, realm.tint, spacing = 0.08f)
            rrect(c, bx, 28f, bw, 9f, 4.5f, col(0xAA000000))
            rrect(c, bx, 28f, bw * (boss.hp / boss.maxHp).coerceIn(0f, 1f), 9f, 4.5f, realm.tint)
            rrectS(c, bx, 28f, bw, 9f, 4.5f, 1.2f, col(0x88FFFFFF))
        }
        text(c, kills.toString(), SW - 48f, 29f, 13f, Color.WHITE, Paint.Align.RIGHT)
        text(c, "ABATES", SW - 48f, 40f, 8f, withA(Color.WHITE, 0.6f), Paint.Align.RIGHT, false)
        circle(c, SW - 24f, 24f, 15f, col(0x88000000))
        ringS(c, SW - 24f, 24f, 15f, 1.6f, col(0xAAFFFFFF))
        rrect(c, SW - 28f, 18f, 3.5f, 12f, 1f, Color.WHITE)
        rrect(c, SW - 22f, 18f, 3.5f, 12f, 1f, Color.WHITE)

        if (state == ST_PLAY) {
            if (joyId != -1) {
                circle(c, joyBX, joyBY, 40f, col(0x22FFFFFF))
                ringS(c, joyBX, joyBY, 40f, 1.8f, col(0x66FFFFFF))
                circle(c, joyBX + joyX * 40f, joyBY + joyY * 40f, 17f, col(0x88FFFFFF))
            } else if (elapsed < 15f) {
                ringS(c, 90f, SH - 80f, 36f, 1.5f, col(0x33FFFFFF))
                circle(c, 90f, SH - 80f, 14f, col(0x22FFFFFF))
            }
        }

        val dx = dashX()
        val dy = dashY()
        val dReady = dashCd <= 0f
        circle(c, dx, dy, 32f, col(0x88000000))
        if (!dReady) {
            fill(col(0x99000000)); tmpR.set(dx - 32f, dy - 32f, dx + 32f, dy + 32f)
            c.drawArc(tmpR, -90f, 360f * (dashCd / dashCdMax).coerceIn(0f, 1f), true, fp)
        }
        ringS(c, dx, dy, 32f, 2.5f, if (dReady) hero().color else col(0x66FFFFFF))
        text(c, "DASH", dx, dy + 4f, 11f, Color.WHITE)

        val nx = novaX()
        val ny = novaY()
        val nReady = novaCharge >= novaNeed
        if (nReady) glow(c, nx, ny, 52f + 6f * sin(tAnim * 8f), C_GOLD, 0.55f)
        circle(c, nx, ny, 27f, col(0x88000000))
        ringS(c, nx, ny, 27f, 2f, col(0x55FFFFFF))
        fp.style = Paint.Style.STROKE; fp.strokeWidth = 4f; fp.shader = null; fp.color = if (nReady) C_GOLD else col(0xFF7AA0FF)
        tmpR.set(nx - 27f, ny - 27f, nx + 27f, ny + 27f)
        c.drawArc(tmpR, -90f, 360f * novaCharge / novaNeed, false, fp)
        fp.style = Paint.Style.FILL
        text(c, "NOVA", nx, ny + 4f, 11f, if (nReady) C_GOLD else Color.WHITE)

        if (bannerT > 0f) {
            val a = min(1f, bannerT)
            text(c, bannerText, SW / 2 + 1f, 91f, 26f, withA(Color.BLACK, a * 0.6f), spacing = 0.1f)
            text(c, bannerText, SW / 2, 90f, 26f, withA(Color.WHITE, a), spacing = 0.1f)
        }
        if (hintT > 0f) {
            text(c, "Arraste à esquerda para mover  •  ataque automático  •  DASH desvia  •  NOVA limpa a tela",
                SW / 2, SH - 14f, 10.5f, withA(Color.WHITE, min(1f, hintT)), bold = false, maxW = SW - 200f)
        }
    }

    private fun drawLevel(c: Canvas) {
        btns.clear()
        fill(col(0xBB000000)); c.drawRect(0f, 0f, SW, SH, fp)
        text(c, "NOVA LUZ DESPERTA", SW / 2, 60f, 22f, C_GOLD, spacing = 0.1f)
        text(c, "Nível $lvl  •  escolha um poder", SW / 2, 80f, 12f, col(0xFFB0B8C8), bold = false)
        val cw = 176f
        val gap = 14f
        val total = optN * cw + (optN - 1) * gap
        val x0 = (SW - total) / 2
        val y = 98f
        val ch = 184f
        for (k in 0 until optN) {
            val d = UPS[opts[k]]
            val x = x0 + k * (cw + gap)
            btns.add(Btn(B_UP + k, RectF(x, y, x + cw, y + ch)))
            panel(c, x, y, cw, ch, d.color, 0.92f)
            if (pressedId == B_UP + k) rrect(c, x, y, cw, ch, 12f, withA(d.color, 0.3f))
            glow(c, x + cw / 2, y + 40f, 48f, d.color, 0.7f)
            diamond(c, x + cw / 2, y + 40f, 15f, mix(d.color, Color.WHITE, 0.4f))
            text(c, d.name, x + cw / 2, y + 86f, 15f, Color.WHITE, maxW = cw - 14f)
            var ly = y + 106f
            for (l in wrap(d.desc, 11f, cw - 22f)) { text(c, l, x + cw / 2, ly, 11f, col(0xFFC0C8D8), bold = false); ly += 14f }
            val cur = upLv[opts[k]]
            for (p in 0 until d.max) {
                val px0 = x + cw / 2 + (p - (d.max - 1) / 2f) * 12f
                circle(c, px0, y + ch - 20f, 3.5f, if (p < cur) d.color else if (p == cur) Color.WHITE else col(0xFF2A3040))
            }
        }
    }

    private fun drawPause(c: Canvas) {
        btns.clear()
        fill(col(0xBB000000)); c.drawRect(0f, 0f, SW, SH, fp)
        val cx = SW / 2
        text(c, "PAUSADO", cx, 92f, 28f, Color.WHITE, spacing = 0.12f)
        text(c, realm.name, cx, 114f, 12f, realm.accent, bold = false)
        button(c, B_RESUME, cx - 110f, 140f, 220f, 44f, "CONTINUAR", C_GOLD, 16f)
        button(c, B_QUIT, cx - 110f, 196f, 220f, 38f, "DESISTIR DA PARTIDA", C_RED, 12f)
        text(c, "Cristais coletados nesta partida: $runShards", cx, 262f, 11f, col(0xFFB0B8C8), bold = false)
    }

    private fun drawResult(c: Canvas) {
        btns.clear()
        fill(col(0xCC000000)); c.drawRect(0f, 0f, SW, SH, fp)
        val cx = SW / 2
        val acc = if (resWin) C_GOLD else C_RED
        val w = 440f
        val h = 276f
        val x = cx - w / 2
        val y = 40f
        panel(c, x, y, w, h, acc, 0.94f)
        glow(c, cx, y + 20f, 120f, acc, 0.3f)
        text(c, if (resWin) "VITÓRIA!" else if (stIdx == 3) "FIM DA JORNADA" else "DERROTA", cx, y + 40f, 28f, acc, spacing = 0.12f)
        if (stIdx < 3) starRow(c, cx, y + 64f, resStars, 8f)
        text(c, "Pontuação", cx - 100f, y + 108f, 11f, col(0xFFA0A8B8), bold = false)
        text(c, resScore.toString() + (if (resBest) "  NOVO RECORDE!" else ""), cx - 100f, y + 128f, 18f, Color.WHITE)
        text(c, "Abates", cx + 100f, y + 108f, 11f, col(0xFFA0A8B8), bold = false)
        text(c, resKills.toString(), cx + 100f, y + 128f, 18f, Color.WHITE)
        text(c, "Tempo", cx - 100f, y + 158f, 11f, col(0xFFA0A8B8), bold = false)
        text(c, fmt(resTime), cx - 100f, y + 178f, 18f, Color.WHITE)
        text(c, "Cristais ganhos", cx + 100f, y + 158f, 11f, col(0xFFA0A8B8), bold = false)
        diamond(c, cx + 70f, y + 173f, 7f, C_GOLD)
        text(c, "+$resEarn", cx + 82f, y + 179f, 18f, C_GOLD, Paint.Align.LEFT)
        button(c, B_RETRY, cx - 200f, y + 208f, 190f, 44f, "JOGAR DE NOVO", acc, 14f)
        button(c, B_BACK, cx + 10f, y + 208f, 190f, 44f, "REINOS", Color.WHITE, 14f)
    }
}
