package com.lumen.lastlight

import android.content.Context

fun col(v: Long): Int = v.toInt()

/** Progresso salvo automaticamente em SharedPreferences. */
class Save(ctx: Context) {
    private val p = ctx.getSharedPreferences("lumen_save", Context.MODE_PRIVATE)

    var shards: Int
        get() = p.getInt("shards", 0)
        set(v) { p.edit().putInt("shards", v).apply() }
    var unlocked: Int
        get() = p.getInt("unlocked", 0)
        set(v) { p.edit().putInt("unlocked", v).apply() }
    var charSel: Int
        get() = p.getInt("charSel", 0)
        set(v) { p.edit().putInt("charSel", v).apply() }
    var charMask: Int
        get() = p.getInt("charMask", 1)
        set(v) { p.edit().putInt("charMask", v).apply() }
    var sfxOn: Boolean
        get() = p.getBoolean("sfxOn", true)
        set(v) { p.edit().putBoolean("sfxOn", v).apply() }
    var musicOn: Boolean
        get() = p.getBoolean("musicOn", true)
        set(v) { p.edit().putBoolean("musicOn", v).apply() }
    var hapticOn: Boolean
        get() = p.getBoolean("hapticOn", true)
        set(v) { p.edit().putBoolean("hapticOn", v).apply() }
    var storyDone: Boolean
        get() = p.getBoolean("storyDone", false)
        set(v) { p.edit().putBoolean("storyDone", v).apply() }
    var tutorialDone: Boolean
        get() = p.getBoolean("tutorialDone", false)
        set(v) { p.edit().putBoolean("tutorialDone", v).apply() }

    fun stars(s: Int) = p.getInt("stars$s", 0)
    fun setStars(s: Int, v: Int) { p.edit().putInt("stars$s", v).apply() }
    fun best(s: Int) = p.getInt("best$s", 0)
    fun setBest(s: Int, v: Int) { p.edit().putInt("best$s", v).apply() }
    fun perm(i: Int) = p.getInt("perm$i", 0)
    fun setPerm(i: Int, v: Int) { p.edit().putInt("perm$i", v).apply() }

    fun reset() { p.edit().clear().apply() }
}

class Realm(
    val name: String, val sub: String, val bg: Int, val ground: Int, val accent: Int,
    val tint: Int, val dark: Int, val time: Float, val boss: String
)

val REALMS = arrayOf(
    Realm("Floresta Adormecida", "As raízes ainda lembram a luz",
        col(0xFF07140F), col(0xFF0E2B1F), col(0xFF5CFFB0), col(0xFFB04CFF), col(0xFF010403), 80f, "Corvo-Raiz"),
    Realm("Cavernas de Cristal", "Ecos azuis no escuro",
        col(0xFF081022), col(0xFF10213F), col(0xFF5CC8FF), col(0xFFFF4C9A), col(0xFF01030A), 95f, "Rainha Prismática"),
    Realm("Abismo do Eclipse", "Onde a última luz morre",
        col(0xFF160812), col(0xFF2B0F23), col(0xFFFFB347), col(0xFFFF3D3D), col(0xFF080106), 110f, "Titã do Eclipse"),
    Realm("Noite Infinita", "Quanto tempo você resiste?",
        col(0xFF0A0614), col(0xFF170D2C), col(0xFFC38BFF), col(0xFF7A8CFF), col(0xFF030106), 1e9f, "Arauto Eterno")
)

class Hero(val name: String, val title: String, val desc: String, val color: Int, val cost: Int)

val HEROES = arrayOf(
    Hero("Aya", "Guardiã da Aurora", "Raios teleguiados que|perseguem os inimigos.", col(0xFFFFE08A), 0),
    Hero("Kael", "Lâmina Estelar", "Começa com 3 lâminas|orbitais. Muito veloz.", col(0xFF7AE7FF), 250),
    Hero("Mira", "Arco Lunar", "Leque de 3 raios perfurantes.|Frágil, mas devastadora.", col(0xFFE59CFF), 500)
)

class UpDef(val name: String, val desc: String, val max: Int, val color: Int)

val UPS = arrayOf(
    UpDef("Chama Intensa", "+22% de dano", 8, col(0xFFFF8A5C)),
    UpDef("Disparo Veloz", "+18% cadência", 8, col(0xFFFFE066)),
    UpDef("Prisma", "+1 raio por disparo", 4, col(0xFFB48CFF)),
    UpDef("Luz Perfurante", "Raios atravessam +1 inimigo", 4, col(0xFF7AE7FF)),
    UpDef("Passos de Vento", "+10% velocidade", 5, col(0xFF8CFFB0)),
    UpDef("Coração Estelar", "+25 vida máx. e cura", 6, col(0xFFFF6B8B)),
    UpDef("Ímã de Luz", "+40% alcance de coleta", 4, col(0xFF5CC8FF)),
    UpDef("Lâminas Orbitais", "+1 lâmina girando", 6, col(0xFFFFFFFF)),
    UpDef("Regeneração", "+0,9 vida por segundo", 5, col(0xFF6BFF9A)),
    UpDef("Fôlego de Nova", "Nova carrega 20% mais rápido", 4, col(0xFFFFB347)),
    UpDef("Salto Etéreo", "Dash recarrega 20% mais rápido", 4, col(0xFFC38BFF)),
    UpDef("Sorte Crítica", "+10% de chance crítica", 5, col(0xFFFFD35C)),
    UpDef("Aura Solar", "Queima inimigos próximos", 5, col(0xFFFF9F43))
)

class PermDef(val name: String, val desc: String, val color: Int)

val PERMS = arrayOf(
    PermDef("Vitalidade", "+10% de vida inicial", col(0xFFFF6B8B)),
    PermDef("Poder", "+8% de dano", col(0xFFFF8A5C)),
    PermDef("Agilidade", "+5% de velocidade", col(0xFF8CFFB0)),
    PermDef("Ímã Estelar", "+12% alcance de coleta", col(0xFF5CC8FF)),
    PermDef("Brilho", "+8% raio de luz", col(0xFFFFE066)),
    PermDef("Fortuna", "+12% cristais", col(0xFFC38BFF))
)

const val PERM_MAX = 8

class TouchEv(val a: Int, val id: Int, val x: Float, val y: Float)

class Enemy {
    var x = 0f; var y = 0f
    var kx = 0f; var ky = 0f
    var type = 0; var kind = 0; var id = 0
    var hp = 1f; var maxHp = 1f
    var r = 10f; var speed = 40f; var dmg = 5f
    var flash = 0f; var t = 0f; var ang = 0f
    var cd = 0f; var cd2 = 0f; var cd3 = 0f
    var st = 0f; var state = 0; var cnt = 0
    var bladeT = 0f; var auraT = 0f
    var xp = 1
    var boss = false
    var alive = true
}

class Bullet {
    var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
    var dmg = 1f; var pierce = 0; var life = 1f; var r = 4f
    var enemy = false; var crit = false; var color = 0
    var target: Enemy? = null
    var ids = IntArray(8); var nHit = 0
    var alive = true
}

class Pickup(var x: Float, var y: Float, val type: Int, val value: Int) {
    var t = 0f; var mag = false; var vx = 0f; var vy = 0f
}

class Part {
    var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
    var life = 0f; var max = 1f; var size = 3f; var color = 0; var drag = 2f
}

class FText {
    var x = 0f; var y = 0f; var life = 0f; var text = ""; var color = 0; var size = 9f
}

class Ring(val x: Float, val y: Float, val maxR: Float, val max: Float, val color: Int) {
    var life = max
}
